# 🚀 Guía de Deployment Paso a Paso
## ChainAware en GenLayer Mainnet

---

### **Autor**: MiniMax Agent  
### **Fecha**: 2025-11-08  
### **Tiempo Estimado**: 2-4 horas  
### **Dificultad**: Intermedio-Avanzado

---

## 📋 Índice

1. [Preparación del Entorno](#preparación-del-entorno)
2. [Configuración de Variables](#configuración-de-variables)
3. [Instalación de Dependencias](#instalación-de-dependencias)
4. [Configuración de Base de Datos](#configuración-de-base-de-datos)
5. [Deployment del Contrato](#deployment-del-contrato)
6. [Build y Deployment del Frontend](#build-y-deployment-del-frontend)
7. [Configuración de Servicios](#configuración-de-servicios)
8. [Verificación y Testing](#verificación-y-testing)
9. [Post-Deployment](#post-deployment)
10. [Troubleshooting](#troubleshooting)

---

## 🛠️ Preparación del Entorno

### Paso 1: Verificar Requisitos del Sistema

#### Sistema Operativo Soportado
- ✅ Ubuntu 20.04 LTS o superior (Recomendado)
- ✅ Debian 11 o superior
- ✅ CentOS 8 o superior
- ✅ macOS 12.0+ (para desarrollo)
- ✅ Windows 10+ con WSL2

#### Hardware Mínimo
- **CPU**: 4 cores (8 cores recomendado)
- **RAM**: 8GB (16GB recomendado)
- **Disco**: 50GB libres (100GB recomendado)
- **Red**: Conexión estable a internet (100 Mbps+)

#### Verificar Sistema
```bash
# Verificar versión del sistema
lsb_release -a
# o
cat /etc/os-release

# Verificar especificaciones
nproc  # Número de CPUs
free -h  # Memoria RAM
df -h  # Espacio en disco
```

### Paso 2: Instalar Dependencias Base

#### Ubuntu/Debian
```bash
# Actualizar repositorios
sudo apt update && sudo apt upgrade -y

# Instalar herramientas esenciales
sudo apt install -y curl wget git unzip software-properties-common

# Instalar Python 3.11+
sudo add-apt-repository ppa:deadsnakes/ppa
sudo apt update
sudo apt install -y python3.11 python3.11-pip python3.11-venv python3.11-dev

# Verificar instalación
python3.11 --version  # Debe mostrar 3.11.x

# Instalar Node.js 18+
curl -fsSL https://deb.nodesource.com/setup_18.x | sudo -E bash -
sudo apt install -y nodejs

# Verificar instalación
node --version  # Debe mostrar 18.x.x
npm --version   # Debe mostrar 9.x.x

# Instalar PostgreSQL
sudo apt install -y postgresql postgresql-contrib

# Verificar servicios
sudo systemctl status postgresql
sudo systemctl enable postgresql

# Instalar herramientas adicionales
sudo apt install -y nginx redis-server htop vim
```

#### CentOS/RHEL
```bash
# Actualizar sistema
sudo yum update -y

# Instalar EPEL
sudo yum install -y epel-release

# Instalar Node.js
curl -fsSL https://rpm.nodesource.com/setup_18.x | sudo bash -
sudo yum install -y nodejs

# Instalar PostgreSQL
sudo yum install -y postgresql-server postgresql-contrib
sudo postgresql-setup initdb
sudo systemctl start postgresql
sudo systemctl enable postgresql
```

### Paso 3: Configurar Usuario de Aplicación

```bash
# Crear usuario para la aplicación
sudo useradd -m -s /bin/bash chainaware
sudo usermod -aG sudo chainaware

# Cambiar al usuario
sudo su - chainaware

# Crear estructura de directorios
mkdir -p ~/chainaware/{logs,config,data,backups}
cd ~/chainaware

# Configurar permisos
chmod 755 ~/chainaware
chmod 700 ~/chainaware/config
```

---

## ⚙️ Configuración de Variables

### Paso 4: Obtener y Configurar API Keys

#### 4.1 GenLayer Mainnet
```bash
# Instalar GenLayer CLI
pip3.11 install genlayer-cli

# Generar par de claves
genlayer generate-key
# Anotar la clave privada que se muestra

# Verificar instalación
genlayer --version
```

#### 4.2 OpenAI API Key
1. **Ir a OpenAI Platform**
   - URL: https://platform.openai.com/api-keys
   - Crear cuenta o iniciar sesión

2. **Crear API Key**
   - Clic en "Create new secret key"
   - Copiar la clave (formato: `sk-...`)
   - ⚠️ **Importante**: Solo se muestra una vez

3. **Configurar Límites**
   - Ir a "Usage limits"
   - Establecer límite mensual (ej: $50)

#### 4.3 Weather API Key (OpenWeatherMap)
1. **Registro**
   - URL: https://openweathermap.org/api
   - Crear cuenta gratuita

2. **Obtener API Key**
   - Ir a "My API keys"
   - Copiar la clave predeterminada

3. **Límites Gratuitos**
   - 1000 llamadas/día
   - Actualización cada 10 minutos

#### 4.4 Base de Datos
```bash
# Opciones:
# 1. PostgreSQL Local (desarrollo)
# 2. AWS RDS (producción)
# 3. Google Cloud SQL
# 4. Supabase (desarrollo/ staging)

# Para desarrollo local:
sudo -u postgres psql -c "CREATE USER chainaware WITH PASSWORD 'mi_password_seguro';"
sudo -u postgres psql -c "CREATE DATABASE chainaware OWNER chainaware;"
sudo -u postgres psql -c "GRANT ALL PRIVILEGES ON DATABASE chainaware TO chainaware;"

# Verificar conexión
psql -h localhost -U chainaware -d chainaware
```

### Paso 5: Configurar Archivo .env

```bash
# Copiar template
cp .env.example .env

# Editar archivo
nano .env
```

**Contenido del archivo `.env`**:
```bash
# ======================================
# CHAINAWARE MAINNET CONFIGURATION
# ======================================

# GENLAYER (REQUERIDO)
GENLAYER_RPC_URL=https://api.genlayer.com
GENLAYER_PRIVATE_KEY=tu_clave_privada_genlayer_aqui

# NETWORK
CHAINAWARE_NETWORK=mainnet
CHAINAWARE_ENVIRONMENT=production

# AI & APIs (REQUERIDO)
OPENAI_API_KEY=sk-tu-clave-openai-aqui
WEATHER_API_KEY=tu_clave_weather_api_aqui
REGULATORY_API_KEY=tu_clave_regulatoria_aqui
VALIDATION_API_KEY=tu_clave_validacion_aqui

# DATABASE (REQUERIDO)
DATABASE_URL=postgresql://chainaware:mi_password_seguro@localhost:5432/chainaware

# SECURITY (REQUERIDO)
JWT_SECRET=tu_secreto_jwt_muy_largo_y_seguro_aqui

# FRONTEND (REQUERIDO)
FRONTEND_URL=http://localhost:5173
API_BASE_URL=http://localhost:8000

# MONITORING
PROMETHEUS_PORT=9091
GRAFANA_PORT=3000
ALERT_EMAIL=admin@tuempresa.com

# NOTIFICATIONS
ALERT_SLACK_WEBHOOK=https://hooks.slack.com/services/TU/SLACK/WEBHOOK

# CLOUD SERVICES (OPCIONAL)
AWS_ACCESS_KEY_ID=tu_aws_access_key
AWS_SECRET_ACCESS_KEY=tu_aws_secret_key
AWS_REGION=us-east-1
AWS_S3_BUCKET=chainaware-assets

# CONFIGURACIÓN DE SEGURIDAD
CORS_ORIGINS=http://localhost:5173
RATE_LIMIT_REQUESTS_PER_HOUR=5000
CACHE_TTL=7200

# FEATURES
FEATURE_AI_PREDICTIONS=true
FEATURE_REAL_TIME_MONITORING=true
FEATURE_DOCUMENT_VERIFICATION=true
FEATURE_NATURAL_LANGUAGE=true
```

**Generar JWT Secret seguro**:
```bash
# Opción 1: Python
python3.11 -c "import secrets; print(secrets.token_urlsafe(32))"

# Opción 2: OpenSSL
openssl rand -base64 32

# Opción 3: Node.js
node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
```

---

## 📦 Instalación de Dependencias

### Paso 6: Setup del Entorno Python

```bash
# Crear entorno virtual
python3.11 -m venv venv
source venv/bin/activate

# Actualizar pip
pip install --upgrade pip

# Instalar dependencias
pip install -r requirements-mainnet.txt

# Verificar instalación
pip list | grep -E "(genlayer|pydantic|sqlalchemy|openai)"

# Generar requirements actualizados
pip freeze > requirements.lock
```

### Paso 7: Setup del Entorno Node.js

```bash
# Instalar dependencias del frontend
npm install

# Verificar instalación
npm list

# Build de prueba
npm run build
```

### Paso 8: Validar Configuración

```bash
# Ejecutar script de validación
python validate_pre_deployment.py
```

**Salida esperada**:
```
=== VALIDATION PRE-DEPLOYMENT ===
✅ Python 3.11+ installed
✅ Node.js 18+ installed
✅ GenLayer CLI configured
✅ Environment variables loaded
✅ Database connection OK
✅ OpenAI API key valid
✅ Weather API key valid
✅ All dependencies installed
✅ Directory structure OK

Validación completa: ✅ PASSED
```

Si hay errores, revisar la sección de [Troubleshooting](#troubleshooting).

---

## 🗄️ Configuración de Base de Datos

### Paso 9: Setup PostgreSQL

#### 9.1 Configuración Básica
```bash
# Conectar como usuario postgres
sudo -u postgres psql

# En psql, ejecutar:
\password postgres  # Establecer password para postgres

# Salir de psql
\q
```

#### 9.2 Configurar para ChainAware
```bash
# Conectar con nuevo usuario
psql -U chainaware -d chainaware

# En psql, crear esquema:
CREATE SCHEMA chainaware;
CREATE TABLE IF NOT EXISTS chainaware.products (
    id VARCHAR(50) PRIMARY KEY,
    name VARCHAR(255) NOT NULL,
    product_type VARCHAR(100) NOT NULL,
    origin VARCHAR(100) NOT NULL,
    batch_number VARCHAR(100) NOT NULL,
    manufacture_date TIMESTAMP,
    expiry_date TIMESTAMP,
    status VARCHAR(50) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT NOW(),
    updated_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS chainaware.events (
    id VARCHAR(50) PRIMARY KEY,
    product_id VARCHAR(50) REFERENCES chainaware.products(id),
    event_type VARCHAR(100) NOT NULL,
    location JSONB,
    data JSONB,
    timestamp TIMESTAMP NOT NULL,
    created_at TIMESTAMP DEFAULT NOW()
);

CREATE TABLE IF NOT EXISTS chainaware.alerts (
    id VARCHAR(50) PRIMARY KEY,
    product_id VARCHAR(50) REFERENCES chainaware.products(id),
    type VARCHAR(100) NOT NULL,
    severity VARCHAR(20) NOT NULL,
    message TEXT NOT NULL,
    status VARCHAR(20) DEFAULT 'active',
    created_at TIMESTAMP DEFAULT NOW(),
    resolved_at TIMESTAMP
);

# Crear índices para performance
CREATE INDEX idx_products_type ON chainaware.products(product_type);
CREATE INDEX idx_events_product ON chainaware.events(product_id);
CREATE INDEX idx_events_timestamp ON chainaware.events(timestamp);
CREATE INDEX idx_alerts_status ON chainaware.alerts(status);

# Salir
\q
```

#### 9.3 Configurar Conexiones Remotas (Opcional)
```bash
# Editar configuración PostgreSQL
sudo nano /etc/postgresql/15/main/postgresql.conf

# Añadir/modificar:
listen_addresses = '*'
port = 5432
max_connections = 200

# Editar pg_hba.conf
sudo nano /etc/postgresql/15/main/pg_hba.conf

# Añadir línea:
host    chainaware    chainaware    0.0.0.0/0    md5

# Reiniciar PostgreSQL
sudo systemctl restart postgresql

# Abrir firewall
sudo ufw allow 5432/tcp
```

### Paso 10: Test de Conexión

```bash
# Test de conexión Python
python3.11 -c "
import os
import psycopg2
try:
    conn = psycopg2.connect(os.getenv('DATABASE_URL'))
    print('✅ Conexión a base de datos exitosa')
    cursor = conn.cursor()
    cursor.execute('SELECT version()')
    print('PostgreSQL version:', cursor.fetchone()[0])
    conn.close()
except Exception as e:
    print(f'❌ Error: {e}')
"
```

---

## 📜 Deployment del Contrato

### Paso 11: Preparar Contrato

```bash
# Verificar estructura del contrato
ls -la contracts/

# Verificar sintaxis Python
python3.11 -m py_compile contracts/chainaware_traceability.py
```

### Paso 12: Deploy a GenLayer Mainnet

```bash
# Verificar conectividad con GenLayer
python3.11 -c "
import os
from genlayer import GenLayerClient
client = GenLayerClient(os.getenv('GENLAYER_RPC_URL'))
print('✅ Conectividad con GenLayer: OK')
"

# Ejecutar deployment
python3.11 deploy_mainnet.py
```

**Salida esperada**:
```
=== CHAINAWARE MAINNET DEPLOYMENT ===
[1/6] Pre-deployment checks... ✅
[2/6] Validating environment... ✅
[3/6] Connecting to GenLayer mainnet... ✅
[4/6] Deploying intelligent contract... 
   - Compiling contract... ✅
   - Deploying to GenLayer... ✅
   - Contract address: 0x742d35Cc6634C0532925a3b8D4e9F4
[5/6] Initializing contract... ✅
[6/6] Setup monitoring... ✅

🎉 DEPLOYMENT COMPLETED SUCCESSFULLY!
Contract Address: 0x742d35Cc6634C0532925a3b8D4e9F4
Network: GenLayer Mainnet
Environment: Production
Timestamp: 2025-01-15T10:30:00Z
```

### Paso 13: Verificar Deployment

```bash
# Test básico del contrato
python3.11 -c "
from contracts.chainaware_traceability import ChainAwareTraceability
import asyncio

async def test_contract():
    contract = ChainAwareTraceability()
    
    # Test registro de producto
    result = await contract.register_product({
        'id': 'TEST-001',
        'name': 'Test Product',
        'product_type': 'pharmaceutical',
        'origin': 'España',
        'batch_number': 'TEST-001',
        'manufacture_date': '2025-01-01',
        'expiry_date': '2026-01-01'
    })
    
    if result['status'] == 'success':
        print('✅ Contrato funcionando correctamente')
    else:
        print(f'❌ Error: {result}')

asyncio.run(test_contract())
"
```

---

## 💻 Build y Deployment del Frontend

### Paso 14: Build del Frontend

```bash
# Crear archivo de configuración de producción
cp .env .env.production

# Editar variables para producción
nano .env.production
```

**Archivo `.env.production`**:
```bash
VITE_GENLAYER_RPC_URL=https://api.genlayer.com
VITE_API_BASE=https://api.chainaware.com
VITE_NETWORK=mainnet
VITE_CONTRACT_ADDRESS=0x742d35Cc6634C0532925a3b8D4e9F4
```

```bash
# Instalar dependencias
npm install --production

# Build para producción
npm run build

# Verificar build
ls -la dist/
# Debe mostrar: index.html, assets/, images/
```

### Paso 15: Servir Frontend

#### Opción 1: Servidor de Desarrollo
```bash
# Ejecutar servidor de desarrollo
npm run dev

# Acceder en: http://localhost:5173
```

#### Opción 2: Servidor de Producción (Nginx)

**Instalar Nginx**:
```bash
sudo apt install -y nginx
sudo systemctl start nginx
sudo systemctl enable nginx
```

**Configurar Nginx**:
```bash
# Crear configuración
sudo nano /etc/nginx/sites-available/chainaware
```

**Contenido del archivo**:
```nginx
server {
    listen 80;
    server_name localhost;
    
    root /home/chainaware/chainaware/dist;
    index index.html;
    
    # Frontend
    location / {
        try_files $uri $uri/ /index.html;
    }
    
    # API proxy
    location /api/ {
        proxy_pass http://127.0.0.1:8000;
        proxy_set_header Host $host;
        proxy_set_header X-Real-IP $remote_addr;
        proxy_set_header X-Forwarded-For $proxy_add_x_forwarded_for;
        proxy_set_header X-Forwarded-Proto $scheme;
    }
    
    # WebSocket para updates
    location /ws {
        proxy_pass http://127.0.0.1:8000;
        proxy_http_version 1.1;
        proxy_set_header Upgrade $http_upgrade;
        proxy_set_header Connection "upgrade";
    }
    
    # Archivos estáticos con cache
    location ~* \.(js|css|png|jpg|jpeg|gif|ico|svg)$ {
        expires 1y;
        add_header Cache-Control "public, immutable";
    }
}
```

```bash
# Habilitar sitio
sudo ln -s /etc/nginx/sites-available/chainaware /etc/nginx/sites-enabled/
sudo nginx -t  # Verificar configuración
sudo systemctl reload nginx
```

#### Opción 3: Docker (Recomendado para producción)

```bash
# Crear Dockerfile
cat > Dockerfile << 'EOF'
FROM node:18-alpine AS builder

WORKDIR /app
COPY package*.json ./
RUN npm ci --only=production

COPY . .
RUN npm run build

FROM nginx:alpine
COPY --from=builder /app/dist /usr/share/nginx/html
COPY nginx.conf /etc/nginx/nginx.conf

EXPOSE 80
CMD ["nginx", "-g", "daemon off;"]
EOF

# Crear nginx.conf
cat > nginx.conf << 'EOF'
events {
    worker_connections 1024;
}

http {
    include /etc/nginx/mime.types;
    default_type application/octet-stream;
    
    server {
        listen 80;
        server_name localhost;
        
        root /usr/share/nginx/html;
        index index.html;
        
        location / {
            try_files $uri $uri/ /index.html;
        }
        
        location /api/ {
            proxy_pass http://host.docker.internal:8000;
        }
    }
}
EOF

# Build y ejecutar
docker build -t chainaware-frontend .
docker run -d -p 80:80 --name chainaware-frontend chainaware-frontend
```

---

## ⚙️ Configuración de Servicios

### Paso 16: Configurar API Server

```bash
# Crear servicio systemd
sudo nano /etc/systemd/system/chainaware-api.service
```

**Contenido del servicio**:
```ini
[Unit]
Description=ChainAware API Server
After=network.target postgresql.service

[Service]
Type=simple
User=chainaware
Group=chainaware
WorkingDirectory=/home/chainaware/chainaware
Environment=PATH=/home/chainaware/chainaware/venv/bin
ExecStart=/home/chainaware/chainaware/venv/bin/python main.py
Restart=always
RestartSec=10
StandardOutput=syslog
StandardError=syslog
SyslogIdentifier=chainaware-api

[Install]
WantedBy=multi-user.target
```

```bash
# Habilitar y iniciar servicio
sudo systemctl daemon-reload
sudo systemctl enable chainaware-api
sudo systemctl start chainaware-api

# Verificar estado
sudo systemctl status chainaware-api
```

### Paso 17: Configurar Monitoreo

#### 17.1 Prometheus
```bash
# Instalar Prometheus
wget https://github.com/prometheus/prometheus/releases/download/v2.45.0/prometheus-2.45.0.linux-amd64.tar.gz
tar xvfz prometheus-*.tar.gz
cd prometheus-*

# Copiar binarios
sudo cp prometheus promtool /usr/local/bin/

# Crear directorio de configuración
sudo mkdir -p /etc/prometheus
sudo cp prometheus.yml /etc/prometheus/

# Crear servicio systemd
sudo nano /etc/systemd/system/prometheus.service
```

**Servicio Prometheus**:
```ini
[Unit]
Description=Prometheus
Wants=network-online.target
After=network-online.target

[Service]
User=prometheus
Group=prometheus
Type=simple
ExecStart=/usr/local/bin/prometheus \
  --config.file /etc/prometheus/prometheus.yml \
  --storage.tsdb.path /var/lib/prometheus/ \
  --web.console.templates=/etc/prometheus/consoles \
  --web.console.libraries=/etc/prometheus/console_libraries \
  --web.listen-address=0.0.0.0:9091 \
  --web.enable-lifecycle

[Install]
WantedBy=multi-user.target
```

```bash
# Crear usuario y directorios
sudo useradd -r -s /bin/false prometheus
sudo mkdir -p /var/lib/prometheus
sudo chown prometheus:prometheus /var/lib/prometheus

# Iniciar servicio
sudo systemctl daemon-reload
sudo systemctl enable prometheus
sudo systemctl start prometheus
```

#### 17.2 Grafana
```bash
# Instalar Grafana
wget -q -O - https://packages.grafana.com/gpg.key | sudo apt-key add -
sudo add-apt-repository "deb https://packages.grafana.com/oss/deb stable main"
sudo apt update
sudo apt install -y grafana

# Habilitar e iniciar
sudo systemctl enable grafana-server
sudo systemctl start grafana-server

# Acceder a: http://localhost:3000
# Usuario: admin, Password: admin
```

#### 17.3 Configurar Métricas en la Aplicación
```python
# Añadir a main.py
from monitoring.business_metrics import start_metrics_server
import threading

# Iniciar servidor de métricas en thread separado
metrics_thread = threading.Thread(target=start_metrics_server, args=(9091,))
metrics_thread.daemon = True
metrics_thread.start()
```

### Paso 18: Configurar Logs

```bash
# Crear directorio de logs
sudo mkdir -p /var/log/chainaware
sudo chown chainaware:chainaware /var/log/chainaware

# Configurar logrotate
sudo nano /etc/logrotate.d/chainaware
```

**Configuración logrotate**:
```
/var/log/chainaware/*.log {
    daily
    missingok
    rotate 30
    compress
    delaycompress
    notifempty
    create 644 chainaware chainaware
    postrotate
        systemctl reload chainaware-api
    endscript
}
```

---

## ✅ Verificación y Testing

### Paso 19: Tests de Funcionalidad

#### 19.1 Test de API
```bash
# Health check
curl -X GET http://localhost:8000/health
# Respuesta esperada: {"status": "healthy", "timestamp": "..."}

# Test de productos
curl -X POST http://localhost:8000/api/products \
  -H "Content-Type: application/json" \
  -d '{
    "name": "Producto de Prueba",
    "type": "pharmaceutical",
    "origin": "España",
    "batch_number": "TEST-001",
    "manufacture_date": "2025-01-15",
    "expiry_date": "2026-01-15"
  }'
```

#### 19.2 Test del Frontend
```bash
# Abrir en navegador
firefox http://localhost  # o http://localhost:5173 para dev

# Verificar en consola del navegador que no hay errores
```

#### 19.3 Test de Monitoreo
```bash
# Verificar Prometheus
curl http://localhost:9091/api/v1/query?query=up
# Debe mostrar métricas de la aplicación

# Verificar Grafana
curl -I http://localhost:3000
# Debe responder 200 OK
```

### Paso 20: Tests de Carga

```bash
# Instalar herramientas de testing
pip install locust

# Crear script de test
cat > test_load.py << 'EOF'
from locust import HttpUser, task, between

class ChainAwareUser(HttpUser):
    wait_time = between(1, 3)
    
    @task
    def health_check(self):
        self.client.get("/health")
    
    @task
    def get_products(self):
        self.client.get("/api/products")
    
    @task
    def create_product(self):
        self.client.post("/api/products", json={
            "name": "Load Test Product",
            "type": "pharmaceutical",
            "origin": "España"
        })
EOF

# Ejecutar test (en otra terminal)
# locust -f test_load.py --host=http://localhost:8000
```

### Paso 21: Verificación de Seguridad

```bash
# Test de headers de seguridad
curl -I http://localhost
# Debe mostrar: X-Frame-Options, X-Content-Type-Options, etc.

# Test de rate limiting
for i in {1..10}; do
  curl -s -o /dev/null -w "%{http_code}\n" http://localhost:8000/api/products
done

# Verificar SSL (si está configurado)
curl -I https://tu-dominio.com
# Debe responder con código 200 y headers de seguridad
```

---

## 📈 Post-Deployment

### Paso 22: Configurar Backup

```bash
# Crear script de backup
cat > ~/chainaware/backup.sh << 'EOF'
#!/bin/bash
BACKUP_DIR="/home/chainaware/chainaware/backups"
DATE=$(date +%Y%m%d_%H%M%S)

# Backup de base de datos
pg_dump -h localhost -U chainaware chainaware > "$BACKUP_DIR/db_$DATE.sql"

# Backup de configuración
cp ~/chainaware/.env "$BACKUP_DIR/env_$DATE"

# Backup de logs (opcional)
tar -czf "$BACKUP_DIR/logs_$DATE.tar.gz" /var/log/chainaware/

# Limpiar backups antiguos (mantener 7 días)
find $BACKUP_DIR -name "*.sql" -mtime +7 -delete
find $BACKUP_DIR -name "env_*" -mtime +7 -delete

echo "Backup completado: $DATE"
EOF

chmod +x ~/chainaware/backup.sh

# Configurar cron para backups diarios
(crontab -l 2>/dev/null; echo "0 2 * * * /home/chainaware/chainaware/backup.sh") | crontab -
```

### Paso 23: Configurar Actualizaciones

```bash
# Crear script de actualización
cat > ~/chainaware/update.sh << 'EOF'
#!/bin/bash
set -e

echo "Iniciando actualización de ChainAware..."

# Backup antes de actualizar
~/chainaware/backup.sh

# Actualizar código
cd ~/chainaware
git pull origin main

# Actualizar dependencias
source venv/bin/activate
pip install -r requirements-mainnet.txt --upgrade

# Rebuild frontend si es necesario
npm install
npm run build

# Reiniciar servicios
sudo systemctl restart chainaware-api
sudo systemctl reload nginx

echo "Actualización completada"
EOF

chmod +x ~/chainaware/update.sh
```

### Paso 24: Configurar Alertas

```bash
# Instalar script de monitoreo
cat > ~/chainaware/monitor.sh << 'EOF'
#!/bin/bash

# Verificar que los servicios estén corriendo
services=("chainaware-api" "postgresql" "nginx" "prometheus" "grafana-server")

for service in "${services[@]}"; do
    if ! systemctl is-active --quiet $service; then
        echo "ALERT: Servicio $service no está corriendo" | mail -s "ChainAware Alert" admin@tuempresa.com
    fi
done

# Verificar uso de disco
DISK_USAGE=$(df / | awk 'NR==2 {print $5}' | sed 's/%//')
if [ $DISK_USAGE -gt 80 ]; then
    echo "ALERT: Uso de disco alto: ${DISK_USAGE}%" | mail -s "ChainAware Disk Alert" admin@tuempresa.com
fi

# Verificar que la API responda
if ! curl -s http://localhost:8000/health > /dev/null; then
    echo "ALERT: API no responde" | mail -s "ChainAware API Alert" admin@tuempresa.com
fi
EOF

chmod +x ~/chainaware/monitor.sh

# Configurar cron para verificar cada 5 minutos
(crontab -l 2>/dev/null; echo "*/5 * * * * /home/chainaware/chainaware/monitor.sh") | crontab -
```

### Paso 25: Configurar SSL/HTTPS (Producción)

#### 25.1 Let's Encrypt
```bash
# Instalar Certbot
sudo apt install -y certbot

# Obtener certificado
sudo certbot --nginx -d tu-dominio.com

# Configurar renovación automática
sudo crontab -e
# Añadir: 0 12 * * * /usr/bin/certbot renew --quiet
```

#### 25.2 Configurar HTTPS en Nginx
```bash
# Editar configuración
sudo nano /etc/nginx/sites-available/chainaware
```

**Configuración HTTPS**:
```nginx
server {
    listen 80;
    server_name tu-dominio.com;
    return 301 https://$server_name$request_uri;
}

server {
    listen 443 ssl http2;
    server_name tu-dominio.com;

    ssl_certificate /etc/letsencrypt/live/tu-dominio.com/fullchain.pem;
    ssl_certificate_key /etc/letsencrypt/live/tu-dominio.com/privkey.pem;

    ssl_protocols TLSv1.2 TLSv1.3;
    ssl_prefer_server_ciphers off;

    # Resto de la configuración igual que antes...
}
```

```bash
sudo nginx -t
sudo systemctl reload nginx
```

---

## 🔧 Troubleshooting

### Problemas Comunes

#### Error: "Database connection failed"
```bash
# Verificar estado de PostgreSQL
sudo systemctl status postgresql

# Verificar configuración
psql -U chainaware -d chainaware -c "SELECT 1;"

# Verificar logs
sudo tail -f /var/log/postgresql/postgresql-15-main.log
```

#### Error: "GenLayer connection timeout"
```bash
# Verificar conectividad
ping api.genlayer.com

# Verificar variables de entorno
cat .env | grep GENLAYER

# Test de conectividad
python3.11 -c "
import os
from genlayer import GenLayerClient
client = GenLayerClient(os.getenv('GENLAYER_RPC_URL'))
print('Conectado')
"
```

#### Error: "OpenAI API rate limit"
```bash
# Verificar límites en OpenAI Platform
# Reducir frecuencia de llamadas
# Implementar retry con backoff
```

#### Error: "Frontend no carga"
```bash
# Verificar logs de Nginx
sudo tail -f /var/log/nginx/error.log

# Verificar permisos
sudo chown -R chainaware:chainaware /home/chainaware/chainaware/dist/

# Verificar configuración
sudo nginx -t
```

#### Error: "Prometheus no recolecta métricas"
```bash
# Verificar configuración
sudo promtool check config /etc/prometheus/prometheus.yml

# Verificar logs
sudo journalctl -u prometheus -f

# Verificar que la app exponga /metrics
curl http://localhost:8000/metrics
```

### Logs Útiles

```bash
# Logs de la aplicación
sudo tail -f /var/log/chainaware/app.log

# Logs de systemd
sudo journalctl -u chainaware-api -f

# Logs de Nginx
sudo tail -f /var/log/nginx/access.log
sudo tail -f /var/log/nginx/error.log

# Logs de PostgreSQL
sudo tail -f /var/log/postgresql/postgresql-15-main.log

# Logs de Prometheus
sudo journalctl -u prometheus -f
```

### Comandos de Diagnóstico

```bash
# Estado de servicios
sudo systemctl status chainaware-api postgresql nginx prometheus grafana-server

# Uso de recursos
htop
df -h
free -h

# Conectividad de red
netstat -tulpn | grep :8000
netstat -tulpn | grep :5432
netstat -tulpn | grep :80

# Procesos de Python
ps aux | grep python

# Verificar puertos
curl -I http://localhost:8000/health
curl -I http://localhost:3000
curl -I http://localhost:9091
```

---

## ✅ Checklist Final

### Configuración
- [ ] Variables de entorno configuradas
- [ ] Base de datos creada y configurada
- [ ] API keys válidas y configuradas
- [ ] Usuario de aplicación creado
- [ ] Directorios con permisos correctos

### Deployment
- [ ] Contrato desplegado en GenLayer mainnet
- [ ] Frontend compilado y servido
- [ ] API server corriendo como servicio
- [ ] Nginx configurado y funcionando
- [ ] Monitoreo (Prometheus + Grafana) configurado

### Seguridad
- [ ] Configuración de firewall
- [ ] Rate limiting configurado
- [ ] HTTPS configurado (producción)
- [ ] Logs configurados
- [ ] Backup automatizado

### Verificación
- [ ] Health checks pasando
- [ ] Tests de funcionalidad pasando
- [ ] Alertas configuradas
- [ ] Documentación actualizada
- [ ] Equipo informado del deployment

### Post-Deployment
- [ ] Backup funcionando
- [ ] Actualizaciones automatizadas
- [ ] Monitoreo activo
- [ ] Documentación de acceso compartida
- [ ] Plan de mantenimiento documentado

---

## 📞 Soporte Post-Deployment

### Contactos de Emergencia
- **Email Técnico**: tech-support@chainaware.com
- **Teléfono 24/7**: +34-XXX-XXX-XXX (Premium Support)
- **Slack Channel**: #chainaware-support
- **Status Page**: https://status.chainaware.com

### Documentación de Acceso
- **API Documentation**: https://api.chainaware.com/docs
- **Admin Panel**: http://tu-dominio.com:3000
- **Monitoring**: http://tu-dominio.com:9091
- **Logs**: `/var/log/chainaware/`

### Mantenimiento
- **Backup**: Automático diario a las 2:00 AM
- **Updates**: Script en `/home/chainaware/chainaware/update.sh`
- **Monitoring**: Script en `/home/chainaware/chainaware/monitor.sh`
- **Support**: Revisar logs antes de reportar problemas

---

**¡Felicidades! Has completado exitosamente el deployment de ChainAware en GenLayer Mainnet.**

**El sistema está ahora operativo y listo para usar. Recuerda configurar monitoreo continuo y mantener backups regulares.**

**Autor**: MiniMax Agent  
**Última actualización**: 2025-11-08