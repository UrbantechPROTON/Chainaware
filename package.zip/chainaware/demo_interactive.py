#!/usr/bin/env python3
"""
ChainAware Interactive Demo
===========================

Demo interactivo que muestra todas las funcionalidades de ChainAware
con datos simulados para demostrar el sistema en acción.
"""

import json
import time
import random
from datetime import datetime, timedelta
from typing import Dict, List, Any
import os

class ChainAwareDemo:
    """Demo interactivo de ChainAware"""
    
    def __init__(self):
        self.products = []
        self.alerts = []
        self.current_time = datetime.now()
        self.contract_address = "0x1a2b3c4d5e6f7890abcdef1234567890"
        self.network = "GenLayer Mainnet"
        
    def print_banner(self):
        """Imprimir banner del demo"""
        print("\n" + "="*80)
        print("🚀 CHANAWARE - INTELLIGENT TRACEABILITY SYSTEM")
        print("="*80)
        print(f"🌐 Network: {self.network}")
        print(f"📍 Contract: {self.contract_address}")
        print(f"⏰ Demo Time: {self.current_time.strftime('%Y-%m-%d %H:%M:%S UTC')}")
        print("="*80)
    
    def print_section(self, title: str):
        """Imprimir sección con formato"""
        print(f"\n{'='*60}")
        print(f"📋 {title.upper()}")
        print(f"{'='*60}")
    
    def simulate_product_registration(self):
        """Simular registro de productos"""
        self.print_section("PRODUCT REGISTRATION SYSTEM")
        
        products_data = [
            {
                "name": "Pfizer COVID-19 Vaccine",
                "category": "pharmaceutical",
                "batch": "PF-2025-001",
                "origin": "Belgium",
                "temperature": 2.5,
                "destination": "Madrid, Spain"
            },
            {
                "name": "Organic Salmon Fillet",
                "category": "food",
                "batch": "SAL-2025-142",
                "origin": "Norway",
                "temperature": -1.8,
                "destination": "London, UK"
            },
            {
                "name": "iPhone 15 Pro",
                "category": "electronics",
                "batch": "APL-2025-789",
                "origin": "China",
                "temperature": 22.0,
                "destination": "New York, USA"
            }
        ]
        
        for i, product in enumerate(products_data, 1):
            print(f"\n🔄 Registering Product {i}...")
            
            # Simular verificación automática con IA
            print(f"🤖 AI Verification: Analyzing {product['category']} product...")
            time.sleep(0.5)
            
            verification_result = {
                "verified": True,
                "confidence": random.uniform(0.85, 0.99),
                "risk_score": random.uniform(0.1, 0.3),
                "fraud_indicators": [],
                "regulatory_compliance": "COMPLIANT"
            }
            
            print(f"✅ Verification Results:")
            print(f"   • Confidence: {verification_result['confidence']:.2%}")
            print(f"   • Risk Score: {verification_result['risk_score']:.2%}")
            print(f"   • Compliance: {verification_result['regulatory_compliance']}")
            
            # Crear producto
            product_id = f"PRD-{i:03d}"
            registered_product = {
                "id": product_id,
                "data": product,
                "registered_at": self.current_time.isoformat(),
                "status": "MANUFACTURED",
                "verification": verification_result,
                "hash": f"0x{hash(product_id + str(product)) % (16**40):040x}"
            }
            
            self.products.append(registered_product)
            
            print(f"📦 Product Registered: {product_id}")
            print(f"   Name: {product['name']}")
            print(f"   Batch: {product['batch']}")
            print(f"   Hash: {registered_product['hash'][:20]}...")
            
            # Simular ubicación inicial
            initial_location = self.get_initial_location(product['origin'])
            registered_product['location'] = initial_location
            print(f"   Initial Location: {initial_location['city']}, {initial_location['country']}")
    
    def simulate_real_time_tracking(self):
        """Simular seguimiento en tiempo real"""
        self.print_section("REAL-TIME TRACKING DASHBOARD")
        
        print("\n📍 Initializing GPS tracking simulation...")
        
        for i, product in enumerate(self.products[:2], 1):  # Track first 2 products
            print(f"\n🛰️  Tracking Product: {product['id']}")
            print(f"📦 {product['data']['name']}")
            
            # Simular ruta de transporte
            route = self.generate_transport_route(
                product['location'], 
                product['data']['destination']
            )
            
            for j, (city, delay) in enumerate(route, 1):
                # Simular actualizaciones en tiempo real
                update_time = self.current_time + timedelta(hours=j*6)
                
                print(f"\n⏰ {update_time.strftime('%H:%M')} - Location Update")
                print(f"📍 Current Location: {city}")
                print(f"🚛 Status: IN_TRANSIT")
                
                if delay > 0:
                    print(f"⚠️  Delay Detected: +{delay} minutes")
                    risk_score = min(0.9, product['verification']['risk_score'] + delay/100)
                    print(f"📊 Risk Score Updated: {risk_score:.2%}")
                
                # Simular datos de sensores
                sensor_data = {
                    "temperature": product['data']['temperature'] + random.uniform(-2, 2),
                    "humidity": random.uniform(45, 65),
                    "shock": random.uniform(0, 0.1),
                    "gps_accuracy": random.uniform(95, 99)
                }
                
                print(f"🌡️  Temperature: {sensor_data['temperature']:.1f}°C")
                print(f"💧 Humidity: {sensor_data['humidity']:.1f}%")
                print(f"🔴 Shock Level: {sensor_data['shock']:.3f}g")
                print(f"📡 GPS Accuracy: {sensor_data['gps_accuracy']:.1f}%")
                
                # Actualizar ubicación
                product['location'] = {
                    "city": city,
                    "country": self.get_country_from_city(city),
                    "lat": random.uniform(-90, 90),
                    "lng": random.uniform(-180, 180),
                    "timestamp": update_time.isoformat()
                }
    
    def simulate_ai_risk_prediction(self):
        """Simular predicción de riesgos con IA"""
        self.print_section("AI RISK PREDICTION MODULE")
        
        print("\n🧠 Initializing AI Risk Prediction Engine...")
        print("📊 Analyzing historical data and patterns...")
        
        for product in self.products:
            print(f"\n🎯 Analyzing Product: {product['id']}")
            print(f"📦 {product['data']['name']}")
            
            # Simular análisis de IA
            print("🤖 AI Analysis:")
            
            # Factores de riesgo
            risk_factors = {
                "weather_conditions": random.choice(["good", "moderate", "poor"]),
                "seasonal_demand": random.choice(["high", "normal", "low"]),
                "regulatory_changes": random.choice(["none", "minor", "major"]),
                "supply_chain_stability": random.uniform(0.7, 0.99)
            }
            
            print(f"   Weather: {risk_factors['weather_conditions']}")
            print(f"   Seasonal Demand: {risk_factors['seasonal_demand']}")
            print(f"   Regulatory: {risk_factors['regulatory_changes']}")
            print(f"   Supply Chain: {risk_factors['supply_chain_stability']:.2%}")
            
            # Predicción de riesgo
            base_risk = product['verification']['risk_score']
            weather_risk = 0.1 if risk_factors['weather_conditions'] == 'poor' else 0
            supply_risk = 1 - risk_factors['supply_chain_stability']
            total_risk = base_risk + weather_risk + supply_risk
            
            risk_level = "LOW" if total_risk < 0.3 else "MEDIUM" if total_risk < 0.6 else "HIGH"
            
            print(f"\n📈 Risk Assessment:")
            print(f"   Base Risk: {base_risk:.2%}")
            print(f"   Weather Impact: {weather_risk:.2%}")
            print(f"   Supply Chain: {supply_risk:.2%}")
            print(f"   Total Risk: {total_risk:.2%}")
            print(f"   Risk Level: {risk_level}")
            
            # Predicciones específicas
            predictions = {
                "delay_probability": random.uniform(0.05, 0.25),
                "quality_issue_risk": random.uniform(0.02, 0.15),
                "security_risk": random.uniform(0.01, 0.10),
                "cost_impact": random.uniform(1.05, 1.30)  # 5-30% cost increase
            }
            
            print(f"\n🔮 AI Predictions:")
            print(f"   Delay Probability: {predictions['delay_probability']:.1%}")
            print(f"   Quality Issue Risk: {predictions['quality_issue_risk']:.1%}")
            print(f"   Security Risk: {predictions['security_risk']:.1%}")
            print(f"   Cost Impact: {predictions['cost_impact']:.1%} (possible)")
            
            # Guardar predicciones
            product['risk_analysis'] = {
                "risk_level": risk_level,
                "total_risk": total_risk,
                "factors": risk_factors,
                "predictions": predictions,
                "analyzed_at": self.current_time.isoformat()
            }
    
    def simulate_intelligent_alerts(self):
        """Simular sistema de alertas inteligentes"""
        self.print_section("INTELLIGENT ALERT SYSTEM")
        
        print("\n🚨 Activating intelligent monitoring...")
        
        # Simular detección de eventos
        alert_events = [
            {
                "type": "TEMPERATURE_DEVIATION",
                "product": "PRD-001",  # Pfizer Vaccine
                "severity": "HIGH",
                "message": "Temperature increased to 8.5°C (normal: 2-8°C)",
                "action_required": "Immediate inspection needed",
                "location": "Amsterdam, Netherlands"
            },
            {
                "type": "DELAY_PREDICTION",
                "product": "PRD-002",  # Salmon
                "severity": "MEDIUM", 
                "message": "Weather delay predicted in North Sea crossing",
                "action_required": "Update delivery schedule",
                "location": "Harwich, UK"
            },
            {
                "type": "ROUTE_DEVIATION",
                "product": "PRD-003",  # iPhone
                "severity": "LOW",
                "message": "Route deviation detected (traffic rerouting)",
                "action_required": "Confirm new ETA",
                "location": "Hamburg, Germany"
            }
        ]
        
        for i, event in enumerate(alert_events, 1):
            print(f"\n⚡ ALERT {i} TRIGGERED")
            print(f"🚨 Type: {event['type']}")
            print(f"🎯 Product: {event['product']}")
            print(f"⚠️  Severity: {event['severity']}")
            print(f"📍 Location: {event['location']}")
            print(f"💬 Message: {event['message']}")
            print(f"🔧 Action Required: {event['action_required']}")
            
            # Simular tiempo de respuesta
            response_time = random.uniform(2, 15)
            print(f"⏱️  Response Time: {response_time:.1f} minutes")
            
            # Simular acción automática
            if event['type'] == 'TEMPERATURE_DEVIATION':
                print("🤖 AI Action: Alert sent to quality control team")
                print("🤖 AI Action: Automatic rerouting to nearest inspection facility")
            elif event['type'] == 'DELAY_PREDICTION':
                print("🤖 AI Action: Delivery schedule updated automatically")
                print("🤖 AI Action: Customer notification sent")
            elif event['type'] == 'ROUTE_DEVIATION':
                print("🤖 AI Action: ETA recalculated and updated")
            
            alert_data = {
                "id": f"ALT-{i:03d}",
                "event": event,
                "detected_at": (self.current_time + timedelta(minutes=i*5)).isoformat(),
                "response_time": response_time,
                "status": "RESOLVED" if response_time < 10 else "IN_PROGRESS"
            }
            
            self.alerts.append(alert_data)
            
            print(f"✅ Alert {event['type']} - Status: {alert_data['status']}")
    
    def simulate_natural_language_query(self):
        """Simular consultas en lenguaje natural"""
        self.print_section("NATURAL LANGUAGE QUERY INTERFACE")
        
        queries = [
            "¿Cuál es el estado del lote PF-2025-001?",
            "¿Hay algún producto en riesgo de demora?",
            "Muestra todos los productos farmacéuticos",
            "¿Cuál es la temperatura del salmón en tránsito?",
            "¿Hay alertas activas en el sistema?"
        ]
        
        for i, query in enumerate(queries, 1):
            print(f"\n💬 Query {i}: \"{query}\"")
            print("🤖 Processing with AI...")
            
            time.sleep(0.5)
            
            # Simular respuestas de IA
            if "estado" in query:
                print("📊 AI Response:")
                print("   Lote PF-2025-001 (Pfizer Vaccine):")
                print("   • Status: IN_TRANSIT")
                print("   • Current Location: Amsterdam, Netherlands")
                print("   • Temperature: 2.5°C (normal)")
                print("   • ETA: 2025-11-08 14:30")
                print("   • Risk Level: LOW")
            elif "demora" in query:
                print("📊 AI Response:")
                print("   1 producto en riesgo de demora detectado:")
                print("   • SAL-2025-142 (Salmon) - Alta probabilidad de retraso")
                print("   • Causa: Condiciones climáticas adversas")
                print("   • Acción: Recalculando ruta")
            elif "farmacéuticos" in query:
                print("📊 AI Response:")
                print("   Productos farmacéuticos activos:")
                print("   • PF-2025-001 - Pfizer Vaccine (En tránsito)")
                print("   • Total: 1 producto activo")
                print("   • Temperatura promedio: 2.5°C")
            elif "temperatura" in query and "salmón" in query:
                print("📊 AI Response:")
                print("   SAL-2025-142 (Salmón):")
                print("   • Temperatura actual: -1.8°C")
                print("   • Rango óptimo: -2°C a 0°C")
                print("   • Estado: NORMAL")
            elif "alertas" in query:
                print("📊 AI Response:")
                print(f"   Alertas activas: {len(self.alerts)}")
                print("   • 1 Alerta RESUELTA (temperatura)")
                print("   • 1 Alerta EN PROGRESO (demora)")
                print("   • 1 Alerta EN PROGRESO (desvío de ruta)")
    
    def generate_performance_metrics(self):
        """Generar métricas de rendimiento"""
        self.print_section("PERFORMANCE METRICS")
        
        print("\n📈 System Performance Dashboard")
        print("-" * 40)
        
        metrics = {
            "total_products": len(self.products),
            "active_tracking": len([p for p in self.products if p['status'] == 'IN_TRANSIT']),
            "alerts_generated": len(self.alerts),
            "average_response_time": sum(alert['response_time'] for alert in self.alerts) / len(self.alerts) if self.alerts else 0,
            "ai_accuracy": random.uniform(0.92, 0.98),
            "system_uptime": "99.9%",
            "data_processing_rate": "1,247 updates/minute",
            "network_transactions": len(self.products) * 3
        }
        
        for key, value in metrics.items():
            formatted_key = key.replace('_', ' ').title()
            if isinstance(value, float) and key == 'ai_accuracy':
                print(f"🤖 {formatted_key}: {value:.1%}")
            elif isinstance(value, float):
                print(f"⏱️  {formatted_key}: {value:.1f}")
            else:
                print(f"📊 {formatted_key}: {value}")
    
    def get_initial_location(self, origin: str) -> Dict[str, Any]:
        """Obtener ubicación inicial basada en origen"""
        locations = {
            "Belgium": {"city": "Antwerp", "country": "Belgium"},
            "Norway": {"city": "Oslo", "country": "Norway"},
            "China": {"city": "Shenzhen", "country": "China"}
        }
        
        return locations.get(origin, {"city": "Unknown", "country": "Unknown"})
    
    def generate_transport_route(self, start: Dict, destination: str) -> List[tuple]:
        """Generar ruta de transporte simulada"""
        if "Spain" in destination:
            return [
                ("Antwerp, Belgium", 0),
                ("Amsterdam, Netherlands", 15),
                ("Frankfurt, Germany", 30),
                ("Lyon, France", 45),
                ("Barcelona, Spain", 0),
                ("Madrid, Spain", 0)
            ]
        elif "UK" in destination:
            return [
                ("Oslo, Norway", 0),
                ("Copenhagen, Denmark", 20),
                ("Hamburg, Germany", 10),
                ("Harwich, UK", 45),  # Weather delay
                ("London, UK", 0)
            ]
        else:  # USA
            return [
                ("Shenzhen, China", 0),
                ("Hong Kong", 0),
                ("Tokyo, Japan", 25),
                ("Anchorage, USA", 0),
                ("Chicago, USA", 0),
                ("New York, USA", 0)
            ]
    
    def get_country_from_city(self, city: str) -> str:
        """Obtener país de una ciudad"""
        countries = {
            "Antwerp": "Belgium",
            "Amsterdam": "Netherlands", 
            "Frankfurt": "Germany",
            "Lyon": "France",
            "Barcelona": "Spain",
            "Madrid": "Spain",
            "Oslo": "Norway",
            "Copenhagen": "Denmark",
            "Hamburg": "Germany",
            "Harwich": "UK",
            "London": "UK",
            "Shenzhen": "China",
            "Hong Kong": "China",
            "Tokyo": "Japan",
            "Anchorage": "USA",
            "Chicago": "USA",
            "New York": "USA"
        }
        return countries.get(city, "Unknown")
    
    def run_complete_demo(self):
        """Ejecutar demo completo"""
        self.print_banner()
        
        # Simular secuencia de funcionalidades
        self.simulate_product_registration()
        input("\n⏸️  Press Enter to continue to real-time tracking...")
        
        self.simulate_real_time_tracking()
        input("\n⏸️  Press Enter to continue to AI risk prediction...")
        
        self.simulate_ai_risk_prediction()
        input("\n⏸️  Press Enter to continue to intelligent alerts...")
        
        self.simulate_intelligent_alerts()
        input("\n⏸️  Press Enter to continue to natural language queries...")
        
        self.simulate_natural_language_query()
        input("\n⏸️  Press Enter to see performance metrics...")
        
        self.generate_performance_metrics()
        
        # Resumen final
        self.print_section("DEMO SUMMARY")
        print("\n🎉 ChainAware Demo Completed Successfully!")
        print(f"✅ {len(self.products)} products registered and tracked")
        print(f"✅ {len(self.alerts)} intelligent alerts generated")
        print(f"✅ AI risk prediction with {random.uniform(0.92, 0.98):.1%} accuracy")
        print(f"✅ Natural language processing active")
        print(f"✅ Real-time monitoring operational")
        
        print(f"\n🔗 System Information:")
        print(f"   Contract Address: {self.contract_address}")
        print(f"   Network: {self.network}")
        print(f"   Demo Completed: {datetime.now().strftime('%Y-%m-%d %H:%M:%S UTC')}")
        
        print(f"\n📋 Next Steps for Production:")
        print(f"   1. Configure API keys and database connection")
        print(f"   2. Deploy to GenLayer Mainnet")
        print(f"   3. Set up IoT sensors integration")
        print(f"   4. Configure monitoring and alerts")
        print(f"   5. Begin production tracking")
        
        print(f"\n🌐 Access Points:")
        print(f"   Dashboard: https://app.chainaware.com")
        print(f"   API: https://api.chainaware.com")
        print(f"   Documentation: https://docs.chainaware.com")
        
        print(f"\n" + "="*80)
        print(f"🚀 Thank you for experiencing ChainAware!")
        print(f"Ready for real-world deployment on GenLayer Mainnet.")
        print(f"="*80)

def main():
    """Función principal del demo"""
    demo = ChainAwareDemo()
    
    print("🎮 Welcome to ChainAware Interactive Demo")
    print("This demo will showcase all key features of the system")
    print("with simulated data and real-time interactions.")
    print("\nPress Enter to begin the demo...")
    input()
    
    demo.run_complete_demo()

if __name__ == "__main__":
    main()