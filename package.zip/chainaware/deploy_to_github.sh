#!/bin/bash

# Script para desplegar ChainAware en GitHub
# Ejecuta este script después de crear el repositorio en GitHub

echo "🚀 Deploying ChainAware to GitHub..."

# Cambiar al directorio del proyecto
cd "$(dirname "$0")"

# Verificar que estamos en el directorio correcto
if [ ! -f "README.md" ] || [ ! -f "contracts/chainaware_traceability.py" ]; then
    echo "❌ Error: No se encuentra el proyecto ChainAware en el directorio actual"
    echo "Asegúrate de ejecutar este script desde la carpeta raíz del proyecto"
    exit 1
fi

# Configurar el remote si no está configurado
if ! git remote get-url origin >/dev/null 2>&1; then
    echo "📋 Configurando remote origin..."
    git remote add origin https://github.com/UrbantechPROTON/Chainaware.git
else
    echo "✅ Remote origin ya configurado"
fi

# Cambiar a la rama main
git branch -M main

# Verificar el estado de git
echo "📊 Estado actual de Git:"
git status --porcelain

# Mostrar archivos que se van a subir
echo ""
echo "📁 Archivos que se subirán:"
git ls-files | sort

# Opción de autenticación
echo ""
echo "🔐 Para autenticarte, puedes:"
echo "1. Usar un token de acceso personal (recomendado):"
echo "   git remote set-url origin https://[TU_USUARIO]:[TU_TOKEN]@github.com/UrbantechPROTON/Chainaware.git"
echo ""
echo "2. O configurar credenciales usando:"
echo "   git config --global credential.helper store"
echo ""

# Preguntar al usuario si quiere continuar
read -p "¿Quieres continuar con el deploy? (y/N): " -n 1 -r
echo
if [[ ! $REPLY =~ ^[Yy]$ ]]; then
    echo "❌ Deploy cancelado por el usuario"
    exit 1
fi

# Intentar hacer push
echo "📤 Subiendo cambios a GitHub..."
if git push -u origin main; then
    echo ""
    echo "🎉 ¡Deploy exitoso!"
    echo "🌐 Tu repositorio está disponible en:"
    echo "   https://github.com/UrbantechPROTON/Chainaware"
    echo ""
    echo "📋 Próximos pasos:"
    echo "1. Revisa el repositorio en GitHub"
    echo "2. Configura la descripción y tags del repositorio"
    echo "3. Habilita GitHub Pages (opcional)"
    echo "4. Configura los webhooks si es necesario"
    echo ""
    echo "🔧 Para desarrollo local:"
    echo "1. Instala dependencias: npm install && pip install -r requirements.txt"
    echo "2. Configura GenLayer CLI"
    echo "3. Ejecuta: npm run dev"
    echo "4. Lee DEMO.md para ejemplos de uso"
else
    echo ""
    echo "❌ Error en el deploy. Posibles soluciones:"
    echo "1. Verifica que el repositorio existe en GitHub"
    echo "2. Configura correctamente las credenciales"
    echo "3. Verifica tu conexión a internet"
    echo ""
    echo "💡 Si usas un token, actualiza el remote con:"
    echo "git remote set-url origin https://[USUARIO]:[TOKEN]@github.com/UrbantechPROTON/Chainaware.git"
    echo "Y vuelve a ejecutar: git push -u origin main"
    exit 1
fi