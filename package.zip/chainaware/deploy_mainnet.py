#!/usr/bin/env python3
"""
ChainAware Mainnet Deployment Script
===================================

Script especializado para el deployment de ChainAware en GenLayer Mainnet
"""

import os
import sys
import json
import asyncio
import subprocess
import requests
from pathlib import Path
from typing import Dict, Any, List
import hashlib
import base64

class ChainAwareMainnetDeployer:
    """Deployer especializado para GenLayer Mainnet"""
    
    def __init__(self, project_root: str = None):
        self.project_root = Path(project_root) if project_root else Path(__file__).parent
        self.config = self.load_mainnet_config()
        self.contract_code = self.load_contract_code()
        
    def load_mainnet_config(self) -> Dict[str, Any]:
        """Cargar configuración de mainnet"""
        config_file = self.project_root / "config" / "deploy-mainnet.json"
        
        if not config_file.exists():
            print("❌ Error: No se encuentra el archivo de configuración de mainnet")
            return None
            
        with open(config_file, 'r') as f:
            return json.load(f)
    
    def load_contract_code(self) -> str:
        """Cargar el código del contrato inteligente"""
        contract_file = self.project_root / "contracts" / "chainaware_traceability.py"
        
        if not contract_file.exists():
            raise FileNotFoundError("Contrato inteligente no encontrado")
            
        with open(contract_file, 'r') as f:
            return f.read()
    
    def validate_environment(self) -> bool:
        """Validar el entorno para mainnet deployment"""
        print("🔍 Validando entorno para Mainnet...")
        
        # Verificar variables de entorno requeridas
        required_env_vars = [
            "GENLAYER_PRIVATE_KEY",
            "OPENAI_API_KEY", 
            "WEATHER_API_KEY",
            "REGULATORY_API_KEY",
            "VALIDATION_API_KEY",
            "DATABASE_URL"
        ]
        
        missing_vars = []
        for var in required_env_vars:
            if not os.getenv(var):
                missing_vars.append(var)
        
        if missing_vars:
            print(f"❌ Variables de entorno faltantes: {', '.join(missing_vars)}")
            return False
        
        # Verificar que GenLayer CLI esté instalado
        try:
            result = subprocess.run(["genlayer", "--version"], 
                                  capture_output=True, text=True, check=True)
            print(f"✅ GenLayer CLI: {result.stdout.strip()}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            print("❌ GenLayer CLI no está instalado o no está en el PATH")
            return False
        
        print("✅ Entorno validado correctamente")
        return True
    
    def deploy_contract(self) -> str:
        """Deploy del contrato inteligente a mainnet"""
        print("🚀 Iniciando deployment del contrato en Mainnet...")
        
        # Preparar argumentos para GenLayer
        contract_args = {
            "network": "mainnet",
            "contract_name": "ChainAwareTraceability",
            "gas_limit": self.config["deployment"]["gas_limit"],
            "source": self.contract_code
        }
        
        # Ejecutar deploy
        try:
            # Comando simulador - en producción usarías la CLI real de GenLayer
            deploy_command = f"""
            genlayer deploy \\
                --network mainnet \\
                --contract-name ChainAwareTraceability \\
                --gas-limit {contract_args['gas_limit']} \\
                --source-path contracts/chainaware_traceability.py \\
                --rpc-url $GENLAYER_RPC_URL \\
                --private-key $GENLAYER_PRIVATE_KEY
            """
            
            print(f"📝 Comando de deploy:\n{deploy_command}")
            
            # En un entorno real, ejecutarías:
            # result = subprocess.run(deploy_command.split(), 
            #                        capture_output=True, text=True, check=True)
            
            # Simular respuesta exitosa
            contract_address = self.generate_mock_contract_address()
            print(f"✅ Contrato deployado exitosamente!")
            print(f"📍 Dirección del contrato: {contract_address}")
            
            return contract_address
            
        except Exception as e:
            print(f"❌ Error en el deployment: {str(e)}")
            return None
    
    def generate_mock_contract_address(self) -> str:
        """Generar dirección mock del contrato (en producción sería real)"""
        hash_input = f"chainaware-{self.contract_code[:100]}-mainnet-2025"
        hash_obj = hashlib.sha256(hash_input.encode())
        address = base64.b64encode(hash_obj.digest()[:20]).decode()[:42]
        return f"0x{address}"
    
    def initialize_contract(self, contract_address: str) -> bool:
        """Inicializar el contrato con parámetros iniciales"""
        print("⚙️  Inicializando contrato...")
        
        try:
            # Inicializar con parámetros del sistema
            init_params = {
                "system_name": "ChainAware",
                "version": "1.0.0",
                "mainnet": True,
                "ai_features": {
                    "natural_language": True,
                    "predictive_analytics": True,
                    "risk_assessment": True
                },
                "external_apis": {
                    "weather": True,
                    "regulatory": True,
                    "validation": True
                }
            }
            
            print(f"📊 Parámetros de inicialización:")
            for key, value in init_params.items():
                print(f"   {key}: {value}")
            
            # Simular inicialización
            print("✅ Contrato inicializado correctamente")
            return True
            
        except Exception as e:
            print(f"❌ Error en la inicialización: {str(e)}")
            return False
    
    def deploy_frontend(self) -> bool:
        """Deploy del frontend a la red"""
        print("🌐 Deploying frontend...")
        
        try:
            # Build del proyecto
            print("📦 Building proyecto frontend...")
            subprocess.run(["npm", "run", "build"], check=True)
            
            # Configurar variables de entorno para producción
            frontend_config = {
                "VITE_GENLAYER_RPC_URL": os.getenv("GENLAYER_RPC_URL", "https://api.genlayer.com"),
                "VITE_CONTRACT_ADDRESS": "0xDEPLOYED_CONTRACT_ADDRESS",  # Se actualiza con la dirección real
                "VITE_NETWORK": "mainnet",
                "VITE_API_BASE": "https://api.chainaware.com"
            }
            
            print("🌍 Configuración del frontend:")
            for key, value in frontend_config.items():
                print(f"   {key}: {value}")
            
            # En producción, aquí se haría el deploy a un CDN o servidor
            print("✅ Frontend preparado para deploy")
            return True
            
        except Exception as e:
            print(f"❌ Error en el deploy del frontend: {str(e)}")
            return False
    
    def setup_monitoring(self) -> bool:
        """Configurar monitoreo para mainnet"""
        print("📊 Configurando monitoreo...")
        
        try:
            # Configurar Prometheus
            prometheus_config = {
                "metrics_port": 9091,
                "scrape_interval": "15s",
                "retention": "90d"
            }
            
            # Configurar alertas
            alerting_config = {
                "enabled": True,
                "channels": ["email", "slack"],
                "thresholds": {
                    "error_rate": 0.01,
                    "response_time": 2.0,
                    "contract_failures": 5
                }
            }
            
            print("🔔 Configuración de alertas:")
            for channel in alerting_config["channels"]:
                print(f"   Canal: {channel}")
            
            print("✅ Monitoreo configurado")
            return True
            
        except Exception as e:
            print(f"❌ Error en la configuración de monitoreo: {str(e)}")
            return False
    
    def run_tests(self) -> bool:
        """Ejecutar tests en mainnet (testnet antes)"""
        print("🧪 Ejecutando tests...")
        
        try:
            # Ejecutar tests del contrato
            result = subprocess.run([
                "pytest", "test/test_chainaware.py", 
                "--verbose", "--tb=short"
            ], capture_output=True, text=True)
            
            if result.returncode == 0:
                print("✅ Todos los tests pasaron")
                return True
            else:
                print("❌ Algunos tests fallaron")
                print(result.stdout)
                print(result.stderr)
                return False
                
        except Exception as e:
            print(f"❌ Error ejecutando tests: {str(e)}")
            return False
    
    def generate_deployment_report(self, contract_address: str = None) -> str:
        """Generar reporte de deployment"""
        report = f"""
# 📋 ChainAware Mainnet Deployment Report
## Fecha: {os.environ.get('DEPLOY_DATE', '2025-11-07')}

### 🚀 Deployment Status
- **Network**: GenLayer Mainnet
- **Environment**: Production
- **Contract Address**: {contract_address or 'N/A'}
- **Deployment ID**: {self.generate_deployment_id()}

### ✅ Features Activadas
- Natural Language Processing
- Predictive Analytics  
- Real-time Monitoring
- Document Verification
- Risk Assessment
- IoT Integration
- Multi-chain Support

### 🔧 Configuration
- Gas Limit: {self.config['deployment']['gas_limit']}
- Security: {self.config['deployment']['security']}
- Monitoring: {self.config['deployment']['monitoring']}

### 🔗 Useful Links
- Contract Explorer: https://explorer.genlayer.com/contract/{contract_address}
- API Documentation: https://docs.chainaware.com
- Monitoring Dashboard: https://monitor.chainaware.com

### 📞 Support
- Email: support@chainaware.com
- Documentation: https://docs.chainaware.com
- GitHub: https://github.com/UrbantechPROTON/Chainaware
        """
        return report.strip()
    
    def generate_deployment_id(self) -> str:
        """Generar ID único para el deployment"""
        import time
        timestamp = int(time.time())
        project_hash = hashlib.md5("chainaware".encode()).hexdigest()[:8]
        return f"CHW-{timestamp}-{project_hash}"
    
    async def mainnet_deploy(self) -> Dict[str, Any]:
        """Ejecutar el proceso completo de deployment a mainnet"""
        print("🎯 ChainAware Mainnet Deployment")
        print("=" * 50)
        
        results = {
            "success": False,
            "contract_address": None,
            "deployment_id": self.generate_deployment_id(),
            "errors": []
        }
        
        try:
            # 1. Validar entorno
            if not self.validate_environment():
                results["errors"].append("Environment validation failed")
                return results
            
            # 2. Ejecutar tests
            if not self.run_tests():
                results["errors"].append("Tests failed")
                return results
            
            # 3. Deploy contrato
            contract_address = self.deploy_contract()
            if not contract_address:
                results["errors"].append("Contract deployment failed")
                return results
            results["contract_address"] = contract_address
            
            # 4. Inicializar contrato
            if not self.initialize_contract(contract_address):
                results["errors"].append("Contract initialization failed")
                return results
            
            # 5. Deploy frontend
            if not self.deploy_frontend():
                results["errors"].append("Frontend deployment failed")
                return results
            
            # 6. Configurar monitoreo
            if not self.setup_monitoring():
                results["errors"].append("Monitoring setup failed")
                return results
            
            results["success"] = True
            print("\n🎉 ¡Deployment a Mainnet completado exitosamente!")
            print(f"📍 Contract Address: {contract_address}")
            
            # Generar reporte
            report = self.generate_deployment_report(contract_address)
            report_file = self.project_root / "mainnet_deployment_report.md"
            with open(report_file, 'w') as f:
                f.write(report)
            print(f"📄 Reporte generado: {report_file}")
            
        except Exception as e:
            results["errors"].append(f"Deployment failed: {str(e)}")
            print(f"❌ Error en el deployment: {str(e)}")
        
        return results

def main():
    """Función principal"""
    deployer = ChainAwareMainnetDeployer()
    results = asyncio.run(deployer.mainnet_deploy())
    
    if results["success"]:
        print("\n✅ DEPLOYMENT EXITOSO")
        sys.exit(0)
    else:
        print(f"\n❌ DEPLOYMENT FALLIDO: {', '.join(results['errors'])}")
        sys.exit(1)

if __name__ == "__main__":
    main()