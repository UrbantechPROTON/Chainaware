# 🔧 Guía de Configuración de Variables de Entorno
## ChainAware - Deployment en GenLayer Mainnet

---

## 📋 Índice
1. [Variables Requeridas](#variables-requeridas)
2. [Variables Opcionales](#variables-opcionales)
3. [Paso a Paso para Obtener API Keys](#paso-a-paso-para-obtener-api-keys)
4. [Configuración de Base de Datos](#configuración-de-base-de-datos)
5. [Configuración de Seguridad](#configuración-de-seguridad)
6. [Servicios en la Nube](#servicios-en-la-nube)
7. [Validación de Configuración](#validación-de-configuración)

---

## 🔑 Variables Requeridas

### 1. GENLAYER MAINNET

#### `GENLAYER_RPC_URL`
- **Descripción**: URL de la API de GenLayer Mainnet
- **Valor**: `https://api.genlayer.com`
- **Nota**: Esta URL es proporcionada por GenLayer para la red principal

#### `GENLAYER_PRIVATE_KEY`
- **Descripción**: Clave privada para deployment de contratos
- **Cómo obtenerla**:
  1. Instalar GenLayer CLI: `pip install genlayer`
  2. Generar nueva clave: `genlayer generate-key`
  3. Copiar la clave privada generada
- **⚠️ IMPORTANTE**: 
  - NUNCA compartir esta clave públicamente
  - No subirla al repositorio
  - Hacer backup seguro

### 2. AI & APIs

#### `OPENAI_API_KEY`
- **Descripción**: Clave para GPT-4 y procesamiento de lenguaje natural
- **Cómo obtenerla**:
  1. Ir a [OpenAI Platform](https://platform.openai.com/api-keys)
  2. Iniciar sesión o crear cuenta
  3. Ir a "API Keys" en el menú lateral
  4. Crear nueva clave secreta
  5. Copiar la clave (formato: `sk-...`)
- **Costo**: Aproximadamente $0.002 por 1K tokens de entrada
- **Límite**: Configurar límites de uso en tu cuenta

#### `WEATHER_API_KEY`
- **Descripción**: API para datos climáticos (temperatura, humedad, etc.)
- **Opciones recomendadas**:
  1. **OpenWeatherMap** (Recomendado)
     - Ir a [openweathermap.org](https://openweathermap.org/api)
     - Crear cuenta gratuita
     - Obtener API key desde el dashboard
     - Costo: 1000 llamadas/día gratis
  
  2. **WeatherAPI**
     - Ir a [weatherapi.com](https://www.weatherapi.com/)
     - Registro gratuito
     - 1 millón de llamadas/mes gratis

- **Formato**: La clave es un string de texto

#### `REGULATORY_API_KEY`
- **Descripción**: API para datos regulatorios y compliance
- **Opciones**:
  1. **Regulations.gov API** (Estados Unidos)
     - Ir a [regulations.gov](https://api.regulations.gov/)
     - Registro requerido
     - Acceso a regulaciones federales
  
  2. **World Bank Open Data** (Internacional)
     - No requiere API key
     - Usar endpoint público
  
  3. **API propia personalizada**
     - Si tienes acceso a bases de datos regulatorias específicas
     - Formato: URL de la API + clave de acceso

#### `VALIDATION_API_KEY`
- **Descripción**: API para verificación de documentos y datos
- **Opciones**:
  1. **Veriff** (Verificación de documentos)
     - Ir a [veriff.com](https://veriff.com/)
     - Registro para desarrolladores
     - API para verificación de identidad
  
  2. **Onfido** (Verificación de documentos)
     - Ir a [onfido.com](https://onfido.com/)
     - APIs para verificación de documentos
  
  3. **Custom API**
     - Si tienes sistema propio de validación
     - Formato: endpoint + API key

### 3. BASE DE DATOS

#### `DATABASE_URL`
- **Descripción**: URL de conexión a la base de datos PostgreSQL
- **Formato**: `postgresql://usuario:contraseña@host:puerto/base_datos`
- **Opciones de hosting**:
  
  **Opción A: PostgreSQL Local**
  ```bash
  DATABASE_URL=postgresql://chainaware:mi_password@localhost:5432/chainaware_db
  ```
  
  **Opción B: AWS RDS**
  ```bash
  DATABASE_URL=postgresql://usuario:password@mi-db.xxxxx.us-east-1.rds.amazonaws.com:5432/chainaware
  ```
  
  **Opción C: Google Cloud SQL**
  ```bash
  DATABASE_URL=postgresql://usuario:password@/chainaware?host=/cloudsql/proyecto:region:instancia
  ```
  
  **Opción D: Supabase (Recomendado para desarrollo)**
  ```bash
  DATABASE_URL=postgresql://postgres:password@db.xxxxxx.supabase.co:5432/postgres
  ```

### 4. SEGURIDAD

#### `JWT_SECRET`
- **Descripción**: Clave secreta para firmar tokens JWT
- **Cómo generarla**:
  ```bash
  # Opción 1: Generar automáticamente en Python
  python3 -c "import secrets; print(secrets.token_urlsafe(32))"
  
  # Opción 2: Generar en Node.js
  node -e "console.log(require('crypto').randomBytes(32).toString('base64'))"
  
  # Opción 3: OpenSSL
  openssl rand -base64 32
  ```
- **Longitud**: Mínimo 32 caracteres
- **Carácteres**: Usar base64, hex, o cualquier string aleatorio

---

## 🔧 Variables Opcionales

### 5. FRONTEND & URLs

#### `FRONTEND_URL`
- **Descripción**: URL donde estará disponible la aplicación frontend
- **Ejemplos**:
  - Desarrollo: `http://localhost:5173`
  - Producción: `https://app.chainaware.com`
  - Staging: `https://staging.chainaware.com`

#### `API_BASE_URL`
- **Descripción**: URL base de la API backend
- **Ejemplos**:
  - Desarrollo: `http://localhost:8000`
  - Producción: `https://api.chainaware.com`

### 6. MONITOREO & LOGS

#### `PROMETHEUS_PORT`
- **Descripción**: Puerto para el servidor de métricas Prometheus
- **Valor por defecto**: `9091`
- **Uso**: Monitoreo de rendimiento y estadísticas

#### `GRAFANA_PORT`
- **Descripción**: Puerto para el dashboard Grafana
- **Valor por defecto**: `3000`
- **Uso**: Visualización de métricas y dashboards

#### `ALERT_EMAIL`
- **Descripción**: Email para recibir alertas del sistema
- **Formato**: `admin@tuempresa.com`
- **Uso**: Notificaciones de errores y problemas

### 7. NOTIFICACIONES

#### `ALERT_SLACK_WEBHOOK`
- **Descripción**: Webhook de Slack para notificaciones
- **Cómo obtenerlo**:
  1. Crear o usar un workspace de Slack
  2. Ir a la configuración de "Incoming Webhooks"
  3. Crear nuevo webhook
  4. Copiar la URL (formato: `https://hooks.slack.com/services/...`)
- **Uso**: Notificaciones en tiempo real al equipo

### 8. SERVICIOS EN LA NUBE

#### AWS (Amazon Web Services)
**`AWS_ACCESS_KEY_ID`**:
- **Cómo obtenerla**:
  1. Ir a AWS Console
  2. Ir a IAM > Users
  3. Crear usuario o usar existente
  4. Ir a Security credentials
  5. Crear access key
  6. Copiar Access Key ID

**`AWS_SECRET_ACCESS_KEY`**:
- Se obtiene junto con la Access Key ID
- ⚠️ Solo se muestra una vez

**`AWS_REGION`**:
- Región donde están tus recursos
- Ejemplos: `us-east-1`, `eu-west-1`, `ap-southeast-1`

**`AWS_S3_BUCKET`**:
- Nombre del bucket S3 para almacenar archivos
- Debe existir antes del deployment

#### Google Cloud Platform
**`GOOGLE_CLOUD_PROJECT`**:
- ID del proyecto en Google Cloud
- Formato: `mi-proyecto-123456`

**`GOOGLE_CREDENTIALS`**:
- Ruta al archivo JSON de service account
- Descargar desde Google Cloud Console

#### Microsoft Azure
**`AZURE_SUBSCRIPTION_ID`**:
- ID de la suscripción de Azure
- Encontrarlo en Azure Portal

**`AZURE_TENANT_ID`**:
- ID del tenant de Azure AD
- En Azure Portal > Azure Active Directory

**`AZURE_CLIENT_ID`**:
- ID de la aplicación registrada
- En Azure Portal > App registrations

**`AZURE_CLIENT_SECRET`**:
- Clave secreta de la aplicación
- Generar en la configuración de la app

---

## 🗄️ Configuración de Base de Datos

### PostgreSQL Local
```bash
# Instalar PostgreSQL
sudo apt update
sudo apt install postgresql postgresql-contrib

# Crear usuario y base de datos
sudo -u postgres psql
CREATE USER chainaware WITH PASSWORD 'mi_password_seguro';
CREATE DATABASE chainaware OWNER chainaware;
GRANT ALL PRIVILEGES ON DATABASE chainaware TO chainaware;
\q
```

### Supabase (Recomendado para desarrollo)
1. Ir a [supabase.com](https://supabase.com)
2. Crear cuenta gratuita
3. Crear nuevo proyecto
4. Copiar la URL de conexión desde Settings > Database

### AWS RDS
1. Ir a AWS RDS Console
2. Crear instancia PostgreSQL
3. Configurar seguridad y acceso
4. Copiar endpoint y credenciales

---

## 🛡️ Configuración de Seguridad

### HTTPS/SSL
Para producción es **OBLIGATORIO** usar HTTPS:

```bash
# Let's Encrypt (Gratuito)
sudo certbot certonly --standalone -d app.chainaware.com

# O usar certificados de tu proveedor
SSL_CERT_PATH=/path/to/ssl/cert.pem
SSL_KEY_PATH=/path/to/ssl/key.pem
```

### CORS (Cross-Origin Resource Sharing)
```bash
# URLs permitidas (separadas por comas)
CORS_ORIGINS=https://app.chainaware.com,https://dashboard.chainaware.com
```

### Rate Limiting
```bash
# Límite de requests por hora
RATE_LIMIT_REQUESTS_PER_HOUR=5000

# Límite de requests por minuto
RATE_LIMIT_REQUESTS_PER_MINUTE=100
```

---

## 📧 Configuración de Email (SMTP)

### SendGrid (Recomendado)
1. Ir a [sendgrid.com](https://sendgrid.com)
2. Crear cuenta gratuita
3. Crear API Key
4. Configurar:
   ```bash
   SMTP_HOST=smtp.sendgrid.net
   SMTP_PORT=587
   SMTP_USER=apikey
   SMTP_PASSWORD=tu_api_key_de_sendgrid
   SMTP_FROM=noreply@tuempresa.com
   ```

### Amazon SES
1. Ir a AWS SES Console
2. Verificar dominio/email
3. Crear SMTP credentials
4. Configurar servidor SMTP

### Gmail (Para desarrollo)
```bash
SMTP_HOST=smtp.gmail.com
SMTP_PORT=587
SMTP_USER=tu_email@gmail.com
SMTP_PASSWORD=tu_app_password  # No tu password normal
```

⚠️ **Importante**: Para Gmail necesitas crear una "App Password" en lugar de usar tu password normal.

---

## 📊 Configuración de Monitoreo

### Prometheus
- **Puerto**: 9091 (por defecto)
- **Métricas**: Automáticamente configurado por ChainAware
- **Dashboards**: Ver Grafana

### Grafana
- **Puerto**: 3000 (por defecto)
- **Acceso**: `http://tu-servidor:3000`
- **Usuario por defecto**: `admin`
- **Password por defecto**: `admin` (cambiar en producción)

### Sentry (Error Tracking)
1. Ir a [sentry.io](https://sentry.io)
2. Crear cuenta gratuita
3. Crear nuevo proyecto
4. Copiar DSN desde Settings > Client Keys (DSN)
5. Configurar:
   ```bash
   SENTRY_DSN=https://tu_dsn_de_sentry@sentry.io/proyecto_id
   ```

---

## ✅ Validación de Configuración

### 1. Script de Validación
Ejecutar el script de validación antes del deployment:
```bash
python validate_pre_deployment.py
```

### 2. Verificación Manual
```bash
# Verificar variables de entorno
python -c "
import os
required_vars = [
    'GENLAYER_RPC_URL',
    'GENLAYER_PRIVATE_KEY',
    'OPENAI_API_KEY',
    'DATABASE_URL',
    'JWT_SECRET'
]
for var in required_vars:
    if not os.getenv(var):
        print(f'❌ {var} no está configurada')
    else:
        print(f'✅ {var} configurada')
"

# Test de conexión a base de datos
python -c "
import os
import psycopg2
try:
    conn = psycopg2.connect(os.getenv('DATABASE_URL'))
    print('✅ Conexión a base de datos exitosa')
    conn.close()
except Exception as e:
    print(f'❌ Error de conexión: {e}')
"
```

### 3. Test de APIs
```bash
# Test OpenAI
python -c "
import openai
import os
client = openai.OpenAI(api_key=os.getenv('OPENAI_API_KEY'))
response = client.chat.completions.create(
    model='gpt-3.5-turbo',
    messages=[{'role': 'user', 'content': 'Hello'}]
)
print('✅ OpenAI API funcionando')
"

# Test Weather API
python -c "
import requests
import os
api_key = os.getenv('WEATHER_API_KEY')
if api_key:
    response = requests.get(f'http://api.openweathermap.org/data/2.5/weather?q=London&appid={api_key}')
    if response.status_code == 200:
        print('✅ Weather API funcionando')
    else:
        print('❌ Weather API error')
"
```

---

## 🚀 Siguiente Paso

Una vez configuradas todas las variables:

1. **Copiar el archivo de ejemplo**:
   ```bash
   cp .env.example .env
   ```

2. **Editar con tus valores**:
   ```bash
   nano .env
   ```

3. **Validar configuración**:
   ```bash
   python validate_pre_deployment.py
   ```

4. **Deploy a mainnet**:
   ```bash
   python deploy_mainnet.py
   ```

---

## 📞 Soporte

Si tienes problemas con la configuración:

1. **Verificar logs**: `tail -f /var/log/chainaware/app.log`
2. **Revisar configuración**: `cat .env`
3. **Ejecutar validación**: `python validate_pre_deployment.py`
4. **Consultar documentación**: [README.md](./README.md)

---

**Autor**: MiniMax Agent  
**Fecha**: 2025-11-08  
**Versión**: 1.0.0