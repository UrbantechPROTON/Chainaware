# 🚀 ChainAware Mainnet Deployment Guide

Esta guía te llevará paso a paso para desplegar **ChainAware** en **GenLayer Mainnet**.

## 📋 Prerrequisitos

### 1. Cuentas y API Keys Requeridas

Antes de comenzar, asegúrate de tener:

- ✅ **GenLayer Mainnet Account** (con fondos GLM)
- ✅ **OpenAI API Key** (para procesamiento de lenguaje natural)
- ✅ **Weather API Key** (OpenWeatherMap, WeatherAPI, etc.)
- ✅ **Regulatory API Key** (para verificación de documentos)
- ✅ **Database** (PostgreSQL recomendado para producción)

### 2. Software Requerido

```bash
# Python 3.9+
python --version

# Node.js 18+
node --version

# GenLayer CLI 0.18.0+
pip install genlayer>=0.18.0
```

### 3. GenLayer Setup

```bash
# Generar clave privada para mainnet
genlayer generate-key

# Verificar configuración
genlayer config list
```

## 🔧 Configuración Inicial

### 1. Clonar el Repositorio

```bash
git clone https://github.com/UrbantechPROTON/Chainaware.git
cd Chainaware
```

### 2. Configurar Variables de Entorno

```bash
# Copiar template de variables
cp .env.mainnet .env

# Editar .env con tus valores reales
nano .env
```

**Variables críticas a configurar:**

```bash
# GENLAYER MAINNET
GENLAYER_PRIVATE_KEY=tu_clave_privada_aqui
GENLAYER_RPC_URL=https://api.genlayer.com

# API KEYS
OPENAI_API_KEY=sk-tu-clave-openai
WEATHER_API_KEY=tu-clave-clima
REGULATORY_API_KEY=tu-clave-regulatoria
VALIDATION_API_KEY=tu-clave-validacion

# DATABASE
DATABASE_URL=postgresql://user:pass@host:5432/chainaware

# JWT
JWT_SECRET=tu-jwt-secret-super-seguro
```

### 3. Instalar Dependencias

```bash
# Python dependencies para mainnet
pip install -r requirements-mainnet.txt

# Node.js dependencies
npm install
```

## ✅ Validación Pre-Deployment

Antes del deployment, ejecuta la validación completa:

```bash
# Cargar variables de entorno
source .env

# Ejecutar validación
python validate_pre_deployment.py
```

### Resultados de Validación

- ✅ **PASSED**: Listo para deployment
- ⚠️ **PASSED WITH WARNINGS**: Puede continuar, pero revisa warnings
- ❌ **FAILED**: Corrige errores antes de continuar

## 🚀 Deployment en Mainnet

### Opción 1: Deployment Automático (Recomendado)

```bash
# Hacer el script ejecutable
chmod +x deploy_mainnet.py

# Ejecutar deployment completo
python deploy_mainnet.py
```

El script automatizado:
1. ✅ Valida el entorno
2. ✅ Ejecuta tests
3. ✅ Despliega el contrato
4. ✅ Inicializa el contrato
5. ✅ Configura el frontend
6. ✅ Establece monitoreo

### Opción 2: Deployment Manual

```bash
# 1. Deploy del contrato
genlayer deploy \
    --network mainnet \
    --contract-name ChainAwareTraceability \
    --source-path contracts/chainaware_traceability.py \
    --gas-limit 2000000

# 2. Inicializar contrato
genlayer call ChainAwareTraceability initialize \
    --args '{"system_name": "ChainAware", "version": "1.0.0"}'

# 3. Build del frontend
npm run build

# 4. Deploy frontend a tu CDN/servidor
```

## 🔍 Verificación Post-Deployment

### 1. Verificar Contrato

```bash
# Verificar estado del contrato
genlayer query ChainAwareTraceability get_system_info

# Verificar funciones principales
genlayer query ChainAwareTraceability register_product \
    --args '{"name": "Test Product", "batch": "TEST001"}'
```

### 2. Testing en Mainnet

```bash
# Ejecutar tests en mainnet
python -c "
from contracts.chainaware_traceability import ChainAwareTraceability
import asyncio

async def test_mainnet():
    contract = ChainAwareTraceability('mainnet')
    result = await contract.register_product({
        'name': 'Test Product',
        'batch': 'MAINNET_TEST_001'
    })
    print(f'Test result: {result}')

asyncio.run(test_mainnet())
"
```

### 3. Verificar Frontend

```bash
# Servir frontend localmente para testing
npm run preview

# Verificar en navegador
open http://localhost:4173
```

## 📊 Monitoreo y Alertas

### Dashboard de Monitoreo

Una vez desplegado, puedes acceder a:

- **Metrics**: http://localhost:9091 (Prometheus)
- **Grafana**: http://localhost:3000 (si configurado)
- **API Health**: https://api.chainaware.com/health

### Alertas Configuradas

El sistema envía alertas por:
- 📧 Email: admin@tuempresa.com
- 💬 Slack: Webhook configurado
- 📊 Prometheus: Métricas automáticas

### Métricas Importantes

- **Contract Calls**: Número de llamadas al contrato
- **Response Time**: Tiempo de respuesta promedio
- **Error Rate**: Porcentaje de errores
- **AI Processing**: Uso de APIs de IA
- **Database**: Conexiones y queries

## 🔒 Seguridad en Mainnet

### Best Practices Implementadas

- ✅ **Private Key Security**: Nunca en código, solo en .env
- ✅ **Rate Limiting**: 5000 requests/hora
- ✅ **SSL/TLS**: Conexiones encriptadas
- ✅ **Input Validation**: Validación en todos los endpoints
- ✅ **Audit Logging**: Logging de todas las operaciones
- ✅ **CORS Configuration**: CORS restrictivo

### Seguridad Adicional

```bash
# Configurar firewall
ufw enable
ufw allow 22/tcp
ufw allow 443/tcp
ufw allow 80/tcp

# Instalar fail2ban
apt-get install fail2ban

# Configurar SSL (Let's Encrypt)
certbot --nginx -d api.chainaware.com
```

## 🐛 Troubleshooting

### Problemas Comunes

#### 1. Error: "Insufficient funds"
```bash
# Verificar balance GLM
genlayer balance

# Si necesitas GLM, obtén de faucet o exchange
```

#### 2. Error: "Contract deployment failed"
```bash
# Verificar gas limit
genlayer estimate-gas contracts/chainaware_traceability.py

# Aumentar gas limit en config
```

#### 3. Error: "API key invalid"
```bash
# Verificar variables de entorno
env | grep API_KEY

# Testear API keys individualmente
curl -H "Authorization: Bearer $OPENAI_API_KEY" https://api.openai.com/v1/models
```

#### 4. Error: "Database connection failed"
```bash
# Verificar conexión a DB
psql -h $DB_HOST -p $DB_PORT -U $DB_USER -d $DB_NAME

# Test de conectividad
python -c "
import psycopg2
conn = psycopg2.connect(os.getenv('DATABASE_URL'))
print('DB Connected!')
"
```

### Logs Útiles

```bash
# Ver logs del contrato
genlayer logs ChainAwareTraceability

# Ver logs de aplicación
tail -f /var/log/chainaware/app.log

# Ver logs de GenLayer
genlayer logs --follow
```

## 📈 Optimización de Performance

### Configuración de Producción

```bash
# Workers para Gunicorn
gunicorn app:app -w 4 -k uvicorn.workers.UvicornWorker

# Redis para cache
redis-server --daemonize yes

# Configurar nginx (opcional)
# /etc/nginx/sites-available/chainaware
```

### Monitoring Performance

```bash
# Ver uso de recursos
htop

# Ver uso de memoria
free -h

# Ver uso de disco
df -h

# Ver conexiones de red
netstat -tulpn
```

## 🔄 Mantenimiento

### Actualizaciones de Seguridad

```bash
# Actualizar dependencias
pip install -r requirements-mainnet.txt --upgrade
npm update

# Verificar vulnerabilidades
npm audit
safety check
```

### Backups

```bash
# Backup de base de datos
pg_dump $DATABASE_URL > backup_$(date +%Y%m%d).sql

# Backup de configuración
tar -czf config_backup_$(date +%Y%m%d).tar.gz .env config/
```

### Monitoreo Continuo

```bash
# Script de health check
#!/bin/bash
API_URL="https://api.chainaware.com/health"
RESPONSE=$(curl -s -o /dev/null -w "%{http_code}" $API_URL)
if [ $RESPONSE -eq 200 ]; then
    echo "✅ API OK"
else
    echo "❌ API DOWN - Response: $RESPONSE"
    # Enviar alerta
fi
```

## 📞 Soporte

### Recursos

- 📖 **Documentación**: https://docs.chainaware.com
- 💬 **GitHub Issues**: https://github.com/UrbantechPROTON/Chainaware/issues
- 📧 **Email**: support@chainaware.com
- 🐦 **Twitter**: @ChainAware

### Emergency Contacts

- **On-call**: +1-XXX-XXX-XXXX
- **Email Critical**: critical@chainaware.com
- **Slack**: #chainaware-emergency

## 🎯 Checklist Final

Antes del deploy en producción:

- [ ] ✅ GenLayer CLI instalado y configurado
- [ ] ✅ Clave privada generada y segura
- [ ] ✅ Todas las API keys configuradas
- [ ] ✅ Base de datos configurada y accesible
- [ ] ✅ Variables de entorno completas
- [ ] ✅ Tests pasando en testnet
- [ ] ✅ Validación pre-deployment completa
- [ ] ✅ SSL configurado
- [ ] ✅ Monitoreo habilitado
- [ ] ✅ Backup configurado
- [ ] ✅ Plan de rollback definido
- [ ] ✅ Team notificado del deployment

---

**🎉 ¡Listo para deployar en GenLayer Mainnet!**

*Una vez completado el deployment, tendrás un sistema de trazabilidad inteligente completamente funcional con capacidades de IA avanzadas.*