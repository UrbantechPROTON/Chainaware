"""
Test cases for ChainAware Traceability System
============================================

Comprehensive test suite demonstrating all intelligent features
"""

import pytest
import asyncio
from datetime import datetime, timezone
from chainaware_traceability import (
    ChainAwareTraceability, ProductStatus, RiskLevel, AlertType
)

class TestChainAwareTraceability:
    """Test suite for ChainAware intelligent traceability system"""
    
    @pytest.fixture
    async def contract(self):
        """Create contract instance for testing"""
        contract = ChainAwareTraceability()
        await contract.initialize_system(
            weather_api="test_weather_key",
            traffic_api="test_traffic_key"
        )
        return contract
    
    @pytest.mark.asyncio
    async def test_product_registration(self, contract):
        """Test intelligent product registration with AI validation"""
        product_data = {
            "name": "Pharmaceutical Product X",
            "category": "pharmaceuticals",
            "origin": "Germany",
            "manufacturer": "BioTech Corp",
            "production_date": "2025-11-01T10:00:00Z",
            "batch_number": "BTX-2025-001",
            "specifications": {
                "temperature_requirement": "2-8°C",
                "humidity_max": 65,
                "storage_class": "A"
            },
            "regulatory_codes": ["FDA-12345", "EU-GMP-67890"],
            "sensors_config": {
                "temperature_sensor": True,
                "humidity_sensor": True,
                "gps_tracker": True
            }
        }
        
        # Register product
        product_id = await contract.register_product(product_data)
        
        # Verify registration
        assert product_id is not None
        assert len(product_id) == 16
        assert product_id in contract.products
        
        # Check product data
        product = contract.products[product_id]
        assert product.name == "Pharmaceutical Product X"
        assert product.category == "pharmaceuticals"
        assert product.regulatory_codes == ["FDA-12345", "EU-GMP-67890"]
    
    @pytest.mark.asyncio
    async def test_location_tracking_with_risks(self, contract):
        """Test location tracking with AI risk analysis"""
        # Register a product first
        product_data = {
            "name": "Fresh Produce A",
            "category": "food",
            "origin": "Spain",
            "manufacturer": "AgriFresh Ltd",
            "production_date": "2025-11-07T08:00:00Z",
            "batch_number": "AF-2025-1107",
            "specifications": {
                "temperature_requirement": "0-4°C",
                "humidity_max": 80
            },
            "regulatory_codes": ["EU-FOOD-2025"],
            "sensors_config": {"temperature_sensor": True, "gps_tracker": True}
        }
        
        product_id = await contract.register_product(product_data)
        
        # Update location with normal conditions
        normal_location = {
            "latitude": 40.4168,  # Madrid
            "longitude": -3.7038,
            "timestamp": "2025-11-07T12:00:00Z",
            "temperature": 2.5,
            "humidity": 70
        }
        
        result = await contract.update_location(product_id, normal_location)
        assert result is True
        
        # Update location with high-risk conditions
        risky_location = {
            "latitude": 40.4168,
            "longitude": -3.7038,
            "timestamp": "2025-11-07T15:00:00Z",
            "temperature": 25.0,  # Too warm for fresh produce
            "humidity": 85  # Too humid
        }
        
        result = await contract.update_location(product_id, risky_location)
        assert result is True
        
        # Check if alerts were generated
        product_alerts = [alert for alert in contract.alerts if alert.id.startswith(product_id)]
        assert len(product_alerts) > 0
        
        # Verify alert properties
        high_risk_alerts = [alert for alert in product_alerts if alert.level == RiskLevel.HIGH]
        assert len(high_risk_alerts) > 0
    
    @pytest.mark.asyncio
    async def test_predictive_delivery_risks(self, contract):
        """Test AI-powered delivery risk prediction"""
        # Register product with tracking
        product_data = {
            "name": "Electronics Component B",
            "category": "electronics",
            "origin": "Japan",
            "manufacturer": "TechCorp",
            "production_date": "2025-11-06T14:00:00Z",
            "batch_number": "TC-2025-1106",
            "specifications": {"fragile": True, "esd_sensitive": True},
            "regulatory_codes": ["CE-2025"],
            "sensors_config": {"shock_sensor": True, "gps_tracker": True}
        }
        
        product_id = await contract.register_product(product_data)
        
        # Add initial location
        location = {
            "latitude": 35.6762,  # Tokyo
            "longitude": 139.6503,
            "timestamp": "2025-11-07T10:00:00Z"
        }
        await contract.update_location(product_id, location)
        
        # Predict delivery risks to another location
        destination = {"latitude": 51.5074, "longitude": -0.1278}  # London
        
        risk_prediction = await contract.predict_delivery_risks(product_id, destination)
        
        # Verify prediction structure
        assert hasattr(risk_prediction, 'level')
        assert hasattr(risk_prediction, 'factors')
        assert hasattr(risk_prediction, 'confidence')
        assert hasattr(risk_prediction, 'recommendation')
        assert hasattr(risk_prediction, 'predicted_time')
        
        assert risk_prediction.level in [RiskLevel.LOW, RiskLevel.MEDIUM, RiskLevel.HIGH, RiskLevel.CRITICAL]
        assert 0 <= risk_prediction.confidence <= 1
        assert isinstance(risk_prediction.factors, list)
        assert isinstance(risk_prediction.recommendation, str)
    
    @pytest.mark.asyncio
    async def test_document_verification(self, contract):
        """Test AI-powered document verification"""
        # Test authentic document
        authentic_document = {
            "type": "certificate_of_origin",
            "product": "Fresh Salmon",
            "origin": "Norway",
            "issuer": "Norwegian Fisheries Authority",
            "date": "2025-11-07",
            "certificate_number": "NO-2025-FS-123456",
            "signatures": ["authorized_officer_1", "authorized_officer_2"]
        }
        
        verification_result = await contract.verify_document(authentic_document)
        
        assert "document_hash" in verification_result
        assert "verified" in verification_result
        assert "fraud_score" in verification_result
        assert "regulatory_status" in verification_result
        assert "verification_timestamp" in verification_result
        assert "issues" in verification_result
        
        assert isinstance(verification_result["document_hash"], str)
        assert len(verification_result["document_hash"]) == 64  # SHA256 hash length
        assert isinstance(verification_result["fraud_score"], float)
        assert 0 <= verification_result["fraud_score"] <= 1
    
    @pytest.mark.asyncio
    async def test_natural_language_queries(self, contract):
        """Test natural language query processing"""
        # Register some test products
        await contract.register_product({
            "name": "Pharmaceutical A",
            "category": "pharmaceuticals",
            "origin": "Germany",
            "manufacturer": "BioTech Corp",
            "production_date": "2025-11-01T10:00:00Z",
            "batch_number": "BTC-2025-001",
            "regulatory_codes": ["FDA-123"],
            "sensors_config": {"temperature_sensor": True}
        })
        
        await contract.register_product({
            "name": "Electronics B",
            "category": "electronics",
            "origin": "Japan",
            "manufacturer": "TechCorp",
            "production_date": "2025-11-02T10:00:00Z",
            "batch_number": "TC-2025-002",
            "regulatory_codes": ["CE-456"],
            "sensors_config": {"gps_tracker": True}
        })
        
        # Test various query types
        queries = [
            "Show products from BioTech",
            "What are the high-risk shipments?",
            "Where is product located?",
            "Show alerts for today",
            "Help with product search"
        ]
        
        for query in queries:
            result = await contract.query_natural_language(query)
            
            assert isinstance(result, dict)
            assert "response" in result or "products" in result or "risks" in result or "locations" in result or "alerts" in result
    
    @pytest.mark.asyncio
    async def test_complete_traceability_flow(self, contract):
        """Test complete product traceability from registration to delivery"""
        # 1. Register product
        product_data = {
            "name": "Vaccine Batch C",
            "category": "pharmaceuticals",
            "origin": "Switzerland",
            "manufacturer": "PharmaSwiss",
            "production_date": "2025-11-05T09:00:00Z",
            "batch_number": "PS-2025-1105",
            "specifications": {
                "temperature_requirement": "2-8°C",
                "storage_life": "24_months"
            },
            "regulatory_codes": ["SWISS-MED-2025", "WHO-PREQUAL-789"],
            "sensors_config": {
                "temperature_sensor": True,
                "humidity_sensor": True,
                "gps_tracker": True
            }
        }
        
        product_id = await contract.register_product(product_data)
        
        # 2. Add multiple location updates representing the journey
        journey_locations = [
            {
                "latitude": 46.2044, "longitude": 6.1432,  # Geneva
                "timestamp": "2025-11-05T15:00:00Z",
                "temperature": 4.0, "humidity": 60
            },
            {
                "latitude": 48.8566, "longitude": 2.3522,  # Paris
                "timestamp": "2025-11-06T10:00:00Z",
                "temperature": 3.5, "humidity": 65
            },
            {
                "latitude": 50.1109, "longitude": 8.6821,  # Frankfurt
                "timestamp": "2025-11-07T08:00:00Z",
                "temperature": 5.0, "humidity": 55
            }
        ]
        
        for location in journey_locations:
            await contract.update_location(product_id, location)
        
        # 3. Verify document
        document = {
            "type": "transport_certificate",
            "vaccine_batch": "PS-2025-1105",
            "transport_date": "2025-11-05T15:00:00Z",
            "certificate_number": "TC-2025-1105-001"
        }
        await contract.verify_document(document)
        
        # 4. Get complete traceability
        traceability = await contract.get_product_traceability(product_id)
        
        # Verify complete traceability data
        assert "product" in traceability
        assert "location_history" in traceability
        assert "alerts" in traceability
        assert "current_risk" in traceability
        assert "traceability_score" in traceability
        
        # Verify product information
        product_info = traceability["product"]
        assert product_info["name"] == "Vaccine Batch C"
        assert product_info["category"] == "pharmaceuticals"
        assert product_info["manufacturer"] == "PharmaSwiss"
        
        # Verify location history
        assert len(traceability["location_history"]) == 3
        for location in traceability["location_history"]:
            assert "latitude" in location
            assert "longitude" in location
            assert "timestamp" in location
        
        # Verify traceability score
        assert 0 <= traceability["traceability_score"] <= 100
    
    @pytest.mark.asyncio
    async def test_risk_assessment_accuracy(self, contract):
        """Test accuracy of AI risk assessment"""
        # Register temperature-sensitive product
        product_data = {
            "name": "Biologics Product D",
            "category": "pharmaceuticals",
            "origin": "USA",
            "manufacturer": "BioPharm Inc",
            "production_date": "2025-11-07T08:00:00Z",
            "batch_number": "BPI-2025-1107",
            "specifications": {"temperature_requirement": "2-8°C"},
            "regulatory_codes": ["FDA-APPROVED"],
            "sensors_config": {"temperature_sensor": True}
        }
        
        product_id = await contract.register_product(product_data)
        
        # Test normal conditions
        normal_location = {
            "latitude": 40.7128, "longitude": -74.0060,  # New York
            "timestamp": "2025-11-07T12:00:00Z",
            "temperature": 6.0, "humidity": 50
        }
        
        await contract.update_location(product_id, normal_location)
        
        # Get current risk assessment
        current_risk = await contract._get_current_risk_assessment(product_id)
        assert current_risk is not None
        assert current_risk.level == RiskLevel.LOW  # Normal conditions
        
        # Test extreme conditions
        extreme_location = {
            "latitude": 40.7128, "longitude": -74.0060,
            "timestamp": "2025-11-07T15:00:00Z",
            "temperature": 45.0,  # Way above acceptable range
            "humidity": 90
        }
        
        await contract.update_location(product_id, extreme_location)
        
        # Check if high risk was detected
        product_alerts = [alert for alert in contract.alerts if alert.id.startswith(product_id)]
        high_risk_alerts = [alert for alert in product_alerts if alert.level == RiskLevel.HIGH]
        assert len(high_risk_alerts) > 0
    
    @pytest.mark.asyncio
    async def test_performance_with_multiple_products(self, contract):
        """Test system performance with multiple products"""
        # Register multiple products
        products_to_register = [
            {
                "name": f"Product {i}",
                "category": "general",
                "origin": "Country A",
                "manufacturer": "Company X",
                "production_date": f"2025-11-0{i%7+1}T10:00:00Z",
                "batch_number": f"COX-2025-{i:03d}",
                "regulatory_codes": ["REG-001"],
                "sensors_config": {"gps_tracker": True}
            }
            for i in range(1, 21)  # Register 20 products
        ]
        
        product_ids = []
        for product_data in products_to_register:
            product_id = await contract.register_product(product_data)
            product_ids.append(product_id)
        
        # Verify all products were registered
        assert len(contract.products) == 20
        assert len(product_ids) == 20
        
        # Add location data for each product
        for i, product_id in enumerate(product_ids):
            location = {
                "latitude": 40.0 + (i * 0.1),  # Different locations
                "longitude": -74.0 - (i * 0.1),
                "timestamp": f"2025-11-07T{(12 + i)%24:02d}:00:00Z",
                "temperature": 20 + (i % 10)
            }
            await contract.update_location(product_id, location)
        
        # Test batch queries
        result = await contract.query_natural_language("show all products")
        assert "products" in result
        assert len(result["products"]) == 20
        
        # Test traceability for all products
        for product_id in product_ids:
            traceability = await contract.get_product_traceability(product_id)
            assert "product" in traceability
            assert "location_history" in traceability
            assert "traceability_score" in traceability

if __name__ == "__main__":
    # Run tests
    pytest.main([__file__, "-v"])