#!/usr/bin/env python3
"""
ChainAware Deployment Script
============================

Script para desplegar y configurar el sistema ChainAware
"""

import os
import sys
import json
import asyncio
import subprocess
from pathlib import Path
from typing import Dict, Any

class ChainAwareDeployer:
    """Clase para manejar el deployment de ChainAware"""
    
    def __init__(self, project_root: str = None):
        self.project_root = Path(project_root) if project_root else Path(__file__).parent
        self.config = self.load_config()
        
    def load_config(self) -> Dict[str, Any]:
        """Cargar configuración de deployment"""
        config_file = self.project_root / "config" / "deploy.json"
        
        if not config_file.exists():
            return self.create_default_config()
            
        with open(config_file, 'r') as f:
            return json.load(f)
    
    def create_default_config(self) -> Dict[str, Any]:
        """Crear configuración por defecto"""
        config = {
            "environment": "development",
            "genlayer": {
                "network": "testnet",
                "contract_name": "ChainAwareTraceability",
                "gas_limit": 1000000,
                "timeout": 300
            },
            "apis": {
                "weather": os.getenv("WEATHER_API_KEY", ""),
                "traffic": os.getenv("TRAFFIC_API_KEY", ""),
                "regulatory": os.getenv("REGULATORY_API_KEY", "")
            },
            "database": {
                "url": os.getenv("DATABASE_URL", "sqlite:///chainaware.db"),
                "pool_size": 10
            },
            "features": {
                "ai_predictions": True,
                "real_time_monitoring": True,
                "document_verification": True,
                "natural_language": True
            },
            "security": {
                "encryption": True,
                "audit_log": True,
                "rate_limit": 1000
            }
        }
        
        # Crear directorio config si no existe
        (self.project_root / "config").mkdir(exist_ok=True)
        
        with open(self.project_root / "config" / "deploy.json", 'w') as f:
            json.dump(config, f, indent=2)
            
        return config
    
    async def check_prerequisites(self) -> bool:
        """Verificar prerrequisitos del sistema"""
        print("🔍 Verificando prerrequisitos...")
        
        prerequisites = {
            "Node.js": ["node", "--version"],
            "Python": ["python3", "--version"],
            "GenLayer CLI": ["genlayer", "--version"],
            "Git": ["git", "--version"]
        }
        
        missing_tools = []
        
        for tool, command in prerequisites.items():
            try:
                result = subprocess.run(command, capture_output=True, text=True, check=True)
                print(f"✅ {tool}: {result.stdout.strip()}")
            except (subprocess.CalledProcessError, FileNotFoundError):
                print(f"❌ {tool}: No encontrado")
                missing_tools.append(tool)
        
        if missing_tools:
            print(f"\n⚠️  Herramientas faltantes: {', '.join(missing_tools)}")
            print("Por favor, instala las herramientas faltantes antes de continuar.")
            return False
        
        print("✅ Todos los prerrequisitos están instalados.\n")
        return True
    
    def install_dependencies(self):
        """Instalar dependencias del proyecto"""
        print("📦 Instalando dependencias...")
        
        # Instalar dependencias de Python
        try:
            subprocess.run([
                sys.executable, "-m", "pip", "install", "-r", "requirements.txt"
            ], check=True, cwd=self.project_root)
            print("✅ Dependencias de Python instaladas")
        except subprocess.CalledProcessError as e:
            print(f"❌ Error instalando dependencias de Python: {e}")
            return False
        
        # Instalar dependencias de Node.js
        try:
            subprocess.run(["npm", "install"], check=True, cwd=self.project_root)
            print("✅ Dependencias de Node.js instaladas")
        except subprocess.CalledProcessError as e:
            print(f"❌ Error instalando dependencias de Node.js: {e}")
            return False
        
        return True
    
    async def deploy_smart_contracts(self):
        """Desplegar contratos inteligentes"""
        print("🏗️  Desplegando contratos inteligentes...")
        
        try:
            # Compilar contratos
            result = subprocess.run([
                "genlayer", "compile"
            ], check=True, capture_output=True, text=True, cwd=self.project_root)
            print("✅ Contratos compilados")
            
            # Desplegar en red de prueba
            result = subprocess.run([
                "genlayer", "deploy",
                "--network", self.config["genlayer"]["network"],
                "--contract", self.config["genlayer"]["contract_name"]
            ], check=True, capture_output=True, text=True, cwd=self.project_root)
            
            print("✅ Contratos desplegados exitosamente")
            print(f"📋 Detalles del deployment: {result.stdout}")
            
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"❌ Error en deployment: {e}")
            print(f"Error: {e.stderr}")
            return False
    
    async def initialize_database(self):
        """Inicializar base de datos"""
        print("🗄️  Inicializando base de datos...")
        
        try:
            # Crear tablas necesarias
            db_script = self.project_root / "scripts" / "init_db.py"
            if db_script.exists():
                subprocess.run([sys.executable, str(db_script)], check=True, cwd=self.project_root)
                print("✅ Base de datos inicializada")
            else:
                print("⚠️  Script de inicialización no encontrado, usando configuración por defecto")
            
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"❌ Error inicializando base de datos: {e}")
            return False
    
    async def run_tests(self):
        """Ejecutar suite de pruebas"""
        print("🧪 Ejecutando pruebas...")
        
        try:
            # Pruebas de contratos inteligentes
            result = subprocess.run([
                "pytest", "test/test_chainaware.py", "-v", "--tb=short"
            ], check=True, capture_output=True, text=True, cwd=self.project_root)
            
            print("✅ Todas las pruebas pasaron exitosamente")
            print(f"📊 Resumen de pruebas:\n{result.stdout}")
            
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"❌ Algunas pruebas fallaron: {e}")
            print(f"Error: {e.stderr}")
            return False
    
    def build_frontend(self):
        """Construir frontend para producción"""
        print("🎨 Construyendo frontend...")
        
        try:
            # Construir con Vite
            subprocess.run(["npm", "run", "build"], check=True, cwd=self.project_root)
            print("✅ Frontend construido exitosamente")
            return True
            
        except subprocess.CalledProcessError as e:
            print(f"❌ Error construyendo frontend: {e}")
            return False
    
    def start_services(self):
        """Iniciar servicios de la aplicación"""
        print("🚀 Iniciando servicios...")
        
        services = []
        
        # Iniciar servidor de desarrollo
        try:
            dev_process = subprocess.Popen([
                "npm", "run", "dev"
            ], cwd=self.project_root)
            services.append(dev_process)
            print("✅ Servidor de desarrollo iniciado en http://localhost:3000")
        except Exception as e:
            print(f"❌ Error iniciando servidor: {e}")
        
        # Iniciar servidor de API si existe
        api_script = self.project_root / "scripts" / "start_api.py"
        if api_script.exists():
            try:
                api_process = subprocess.Popen([sys.executable, str(api_script)], cwd=self.project_root)
                services.append(api_process)
                print("✅ Servidor de API iniciado")
            except Exception as e:
                print(f"❌ Error iniciando API: {e}")
        
        return services
    
    def show_deployment_info(self):
        """Mostrar información del deployment"""
        print("\n" + "="*60)
        print("🎉 DEPLOYMENT COMPLETADO EXITOSAMENTE")
        print("="*60)
        print(f"🌐 URL de la aplicación: http://localhost:3000")
        print(f"🔗 Red GenLayer: {self.config['genlayer']['network']}")
        print(f"🏗️  Contrato: {self.config['genlayer']['contract_name']}")
        print("\n📋 Funcionalidades habilitadas:")
        
        for feature, enabled in self.config['features'].items():
            status = "✅" if enabled else "❌"
            print(f"  {status} {feature.replace('_', ' ').title()}")
        
        print("\n🔗 Enlaces útiles:")
        print("  • Dashboard: http://localhost:3000")
        print("  • GenLayer Studio: https://studio.genlayer.com")
        print("  • Documentación: https://docs.chainaware.com")
        
        print("\n📖 Primeros pasos:")
        print("  1. Abre http://localhost:3000 en tu navegador")
        print("  2. Registra tu primer producto")
        print("  3. Prueba las consultas en lenguaje natural")
        print("  4. Explora el dashboard de análisis")
        
        print("\n🆘 Soporte:")
        print("  • Email: support@chainaware.com")
        print("  • Discord: https://discord.gg/chainaware")
        print("  • Issues: https://github.com/chainaware/issues")
    
    async def deploy(self):
        """Ejecutar proceso completo de deployment"""
        print("🚀 Iniciando deployment de ChainAware...")
        print(f"📁 Directorio del proyecto: {self.project_root}\n")
        
        # Verificar prerrequisitos
        if not await self.check_prerequisites():
            return False
        
        # Instalar dependencias
        if not self.install_dependencies():
            return False
        
        # Ejecutar pruebas
        if not await self.run_tests():
            print("⚠️  Algunas pruebas fallaron, pero continuando con el deployment...")
        
        # Desplegar contratos inteligentes
        if not await self.deploy_smart_contracts():
            return False
        
        # Inicializar base de datos
        if not await self.initialize_database():
            return False
        
        # Construir frontend
        if not self.build_frontend():
            return False
        
        # Iniciar servicios
        services = self.start_services()
        
        # Mostrar información del deployment
        self.show_deployment_info()
        
        print("\n🔄 Manteniendo servicios ejecutándose... (Ctrl+C para detener)")
        try:
            for service in services:
                service.wait()
        except KeyboardInterrupt:
            print("\n🛑 Deteniendo servicios...")
            for service in services:
                service.terminate()
            print("✅ Servicios detenidos")
        
        return True

async def main():
    """Función principal"""
    import argparse
    
    parser = argparse.ArgumentParser(description="ChainAware Deployment Tool")
    parser.add_argument("--project-root", help="Directorio raíz del proyecto")
    parser.add_argument("--skip-tests", action="store_true", help="Saltar pruebas")
    parser.add_argument("--skip-contracts", action="store_true", help="Saltar deployment de contratos")
    
    args = parser.parse_args()
    
    deployer = ChainAwareDeployer(args.project_root)
    
    if args.skip_tests:
        print("⚠️  Saltando pruebas...")
    
    if args.skip_contracts:
        print("⚠️  Saltando deployment de contratos...")
    
    success = await deployer.deploy()
    
    if not success:
        print("❌ Deployment falló")
        sys.exit(1)
    else:
        print("🎉 Deployment completado exitosamente")

if __name__ == "__main__":
    asyncio.run(main())