#!/usr/bin/env python3
"""
ChainAware Pre-Deployment Validation
====================================

Script para validar que todo está listo para el deployment en GenLayer Mainnet
"""

import os
import sys
import json
import subprocess
import requests
from pathlib import Path
from typing import List, Dict, Tuple
import re
import hashlib

class PreDeploymentValidator:
    """Validador pre-deployment para GenLayer Mainnet"""
    
    def __init__(self, project_root: str = None):
        self.project_root = Path(project_root) if project_root else Path(__file__).parent
        self.errors = []
        self.warnings = []
        self.passed_checks = []
        
    def print_header(self, title: str):
        """Imprimir header con formato"""
        print(f"\n{'=' * 60}")
        print(f"🔍 {title}")
        print(f"{'=' * 60}")
    
    def print_success(self, message: str):
        """Imprimir mensaje de éxito"""
        print(f"✅ {message}")
        self.passed_checks.append(message)
    
    def print_warning(self, message: str):
        """Imprimir warning"""
        print(f"⚠️  {message}")
        self.warnings.append(message)
    
    def print_error(self, message: str):
        """Imprimir error"""
        print(f"❌ {message}")
        self.errors.append(message)
    
    def check_environment_variables(self) -> bool:
        """Validar variables de entorno"""
        self.print_header("Environment Variables Validation")
        
        required_vars = [
            "GENLAYER_PRIVATE_KEY",
            "OPENAI_API_KEY",
            "WEATHER_API_KEY", 
            "REGULATORY_API_KEY",
            "VALIDATION_API_KEY",
            "DATABASE_URL"
        ]
        
        optional_vars = [
            "TRAFFIC_API_KEY",
            "SMTP_HOST",
            "REDIS_URL"
        ]
        
        all_good = True
        
        print("🔐 Verificando variables requeridas...")
        for var in required_vars:
            value = os.getenv(var)
            if value and value != f"your_{var.lower()}_here":
                if var == "GENLAYER_PRIVATE_KEY" and len(value) < 32:
                    self.print_error(f"{var} parece inválida (muy corta)")
                    all_good = False
                else:
                    self.print_success(f"{var} configurada correctamente")
            else:
                self.print_error(f"{var} no está configurada o usa valor por defecto")
                all_good = False
        
        print(f"\n📝 Verificando variables opcionales...")
        for var in optional_vars:
            value = os.getenv(var)
            if value:
                self.print_success(f"{var} configurada")
            else:
                self.print_warning(f"{var} no configurada (opcional)")
        
        return all_good
    
    def check_genlayer_cli(self) -> bool:
        """Verificar instalación de GenLayer CLI"""
        self.print_header("GenLayer CLI Validation")
        
        try:
            result = subprocess.run(["genlayer", "--version"], 
                                  capture_output=True, text=True, check=True)
            version = result.stdout.strip()
            
            # Verificar versión mínima
            version_match = re.search(r'(\d+\.\d+\.\d+)', version)
            if version_match:
                min_version = "0.18.0"
                if version >= min_version:
                    self.print_success(f"GenLayer CLI: {version} (>= {min_version})")
                    return True
                else:
                    self.print_error(f"GenLayer CLI versión {version} < {min_version}")
                    return False
            else:
                self.print_success(f"GenLayer CLI: {version}")
                return True
                
        except (subprocess.CalledProcessError, FileNotFoundError):
            self.print_error("GenLayer CLI no está instalado o no está en PATH")
            print("💡 Instala con: pip install genlayer>=0.18.0")
            return False
    
    def check_project_structure(self) -> bool:
        """Verificar estructura del proyecto"""
        self.print_header("Project Structure Validation")
        
        required_files = [
            "contracts/chainaware_traceability.py",
            "src/app.js", 
            "src/styles/main.css",
            "test/test_chainaware.py",
            "config/deploy-mainnet.json",
            ".env.mainnet",
            "deploy_mainnet.py",
            "requirements-mainnet.txt"
        ]
        
        optional_files = [
            "README.md",
            "DEMO.md",
            "config/genlayer-mainnet.conf"
        ]
        
        all_good = True
        
        print("📁 Verificando archivos requeridos...")
        for file_path in required_files:
            full_path = self.project_root / file_path
            if full_path.exists():
                self.print_success(f"{file_path} existe")
            else:
                self.print_error(f"{file_path} no encontrado")
                all_good = False
        
        print(f"\n📋 Verificando archivos opcionales...")
        for file_path in optional_files:
            full_path = self.project_root / file_path
            if full_path.exists():
                self.print_success(f"{file_path} existe")
            else:
                self.print_warning(f"{file_path} no encontrado (opcional)")
        
        return all_good
    
    def check_contract_integrity(self) -> bool:
        """Verificar integridad del contrato inteligente"""
        self.print_header("Contract Integrity Validation")
        
        contract_file = self.project_root / "contracts" / "chainaware_traceability.py"
        
        if not contract_file.exists():
            self.print_error("Archivo del contrato no encontrado")
            return False
        
        try:
            with open(contract_file, 'r', encoding='utf-8') as f:
                content = f.read()
            
            # Verificar sintaxis Python
            compile(content, contract_file, 'exec')
            self.print_success("Contrato: Sintaxis Python válida")
            
            # Verificar imports requeridos
            required_imports = [
                "from genlayer import",
                "from pydantic import",
                "from typing import",
                "import datetime"
            ]
            
            for imp in required_imports:
                if imp in content:
                    self.print_success(f"Import: {imp}")
                else:
                    self.print_warning(f"Import no encontrado: {imp}")
            
            # Verificar clase principal
            if "class ChainAwareTraceability" in content:
                self.print_success("Clase principal encontrada")
            else:
                self.print_error("Clase principal ChainAwareTraceability no encontrada")
                all_good = False
            
            # Verificar funciones principales
            required_functions = [
                "register_product",
                "update_location", 
                "predict_risks",
                "process_natural_language_query"
            ]
            
            for func in required_functions:
                if f"def {func}" in content:
                    self.print_success(f"Función: {func}")
                else:
                    self.print_error(f"Función {func} no encontrada")
                    all_good = False
            
            # Verificar hash del archivo
            file_hash = hashlib.sha256(content.encode()).hexdigest()[:16]
            self.print_success(f"Hash del contrato: {file_hash}")
            
            return all_good if 'all_good' in locals() else True
            
        except SyntaxError as e:
            self.print_error(f"Error de sintaxis en contrato: {e}")
            return False
        except Exception as e:
            self.print_error(f"Error leyendo contrato: {e}")
            return False
    
    def check_test_suite(self) -> bool:
        """Verificar suite de tests"""
        self.print_header("Test Suite Validation")
        
        test_file = self.project_root / "test" / "test_chainaware.py"
        
        if not test_file.exists():
            self.print_error("Archivo de tests no encontrado")
            return False
        
        try:
            # Verificar que pytest está disponible
            result = subprocess.run(["pytest", "--version"], 
                                  capture_output=True, text=True)
            if result.returncode == 0:
                self.print_success(f"Pytest: {result.stdout.strip()}")
            else:
                self.print_warning("Pytest no disponible")
            
            # Ejecutar tests
            print("🧪 Ejecutando tests...")
            result = subprocess.run([
                "pytest", str(test_file), "-v", "--tb=short"
            ], capture_output=True, text=True, cwd=self.project_root)
            
            if result.returncode == 0:
                self.print_success("Todos los tests pasaron")
                
                # Buscar número de tests
                output = result.stdout
                if "passed" in output:
                    match = re.search(r'(\d+)\s+passed', output)
                    if match:
                        tests_passed = match.group(1)
                        self.print_success(f"Tests ejecutados: {tests_passed}")
                
                return True
            else:
                self.print_error("Algunos tests fallaron")
                self.print_error(f"Error: {result.stderr}")
                return False
                
        except FileNotFoundError:
            self.print_warning("Pytest no está instalado")
            print("💡 Instala con: pip install pytest pytest-asyncio")
            return True  # No es crítico
        except Exception as e:
            self.print_error(f"Error ejecutando tests: {e}")
            return False
    
    def check_dependencies(self) -> bool:
        """Verificar dependencias"""
        self.print_header("Dependencies Validation")
        
        # Verificar archivo requirements
        requirements_file = self.project_root / "requirements-mainnet.txt"
        
        if not requirements_file.exists():
            self.print_error("requirements-mainnet.txt no encontrado")
            return False
        
        self.print_success("requirements-mainnet.txt encontrado")
        
        # Verificar Python
        python_version = sys.version_info
        if python_version >= (3, 9):
            self.print_success(f"Python: {python_version.major}.{python_version.minor}.{python_version.micro}")
        else:
            self.print_error(f"Python {python_version.major}.{python_version.minor} < 3.9")
            return False
        
        # Verificar Node.js
        try:
            result = subprocess.run(["node", "--version"], 
                                  capture_output=True, text=True, check=True)
            node_version = result.stdout.strip()
            self.print_success(f"Node.js: {node_version}")
        except (subprocess.CalledProcessError, FileNotFoundError):
            self.print_warning("Node.js no encontrado (requerido para frontend)")
        
        return True
    
    def check_network_connectivity(self) -> bool:
        """Verificar conectividad de red"""
        self.print_header("Network Connectivity Validation")
        
        endpoints = [
            ("https://api.genlayer.com", "GenLayer API"),
            ("https://api.openai.com", "OpenAI API"),
            ("https://api.openweathermap.org", "Weather API")
        ]
        
        all_good = True
        
        for url, name in endpoints:
            try:
                response = requests.get(url, timeout=10)
                if response.status_code < 500:
                    self.print_success(f"{name}: {response.status_code}")
                else:
                    self.print_warning(f"{name}: Server Error {response.status_code}")
            except requests.exceptions.RequestException as e:
                self.print_error(f"{name}: No disponible - {e}")
                all_good = False
        
        return all_good
    
    def check_security_configuration(self) -> bool:
        """Verificar configuración de seguridad"""
        self.print_header("Security Configuration Validation")
        
        security_checks = [
            ("GenLayer private key not in version control", self.check_no_secrets_in_git()),
            ("SSL/TLS configuration present", self.check_ssl_config()),
            ("Rate limiting configured", self.check_rate_limiting())
        ]
        
        all_good = True
        
        for check_name, check_result in security_checks:
            if check_result:
                self.print_success(f"Security: {check_name}")
            else:
                self.print_warning(f"Security: {check_name} - needs attention")
                all_good = False
        
        return all_good
    
    def check_no_secrets_in_git(self) -> bool:
        """Verificar que no hay secretos en Git"""
        env_file = self.project_root / ".env.mainnet"
        if env_file.exists():
            # Verificar que el archivo está en .gitignore
            gitignore_file = self.project_root / ".gitignore"
            if gitignore_file.exists():
                with open(gitignore_file, 'r') as f:
                    gitignore_content = f.read()
                    if ".env" in gitignore_content or ".env.mainnet" in gitignore_content:
                        return True
        
        return False
    
    def check_ssl_config(self) -> bool:
        """Verificar configuración SSL"""
        env_file = self.project_root / ".env.mainnet"
        if env_file.exists():
            with open(env_file, 'r') as f:
                content = f.read()
                return "SSL_CERT_PATH" in content
        return False
    
    def check_rate_limiting(self) -> bool:
        """Verificar configuración de rate limiting"""
        config_file = self.project_root / "config" / "deploy-mainnet.json"
        if config_file.exists():
            with open(config_file, 'r') as f:
                config = json.load(f)
                return config.get("deployment", {}).get("security", {}).get("rate_limiting", False)
        return False
    
    def run_all_checks(self) -> Dict[str, any]:
        """Ejecutar todas las validaciones"""
        print("🚀 ChainAware Pre-Deployment Validation")
        print("Iniciando verificación completa para GenLayer Mainnet...")
        
        results = {
            "overall_status": "pending",
            "errors": self.errors,
            "warnings": self.warnings,
            "passed": self.passed_checks,
            "checks": {}
        }
        
        # Ejecutar todas las validaciones
        checks = [
            ("environment_variables", self.check_environment_variables),
            ("genlayer_cli", self.check_genlayer_cli),
            ("project_structure", self.check_project_structure),
            ("contract_integrity", self.check_contract_integrity),
            ("test_suite", self.check_test_suite),
            ("dependencies", self.check_dependencies),
            ("network_connectivity", self.check_network_connectivity),
            ("security_configuration", self.check_security_configuration)
        ]
        
        all_passed = True
        
        for check_name, check_func in checks:
            try:
                result = check_func()
                results["checks"][check_name] = result
                if not result:
                    all_passed = False
            except Exception as e:
                self.print_error(f"Error en {check_name}: {e}")
                results["checks"][check_name] = False
                all_passed = False
        
        # Determinar estado general
        if self.errors:
            results["overall_status"] = "failed"
        elif self.warnings:
            results["overall_status"] = "passed_with_warnings"
        else:
            results["overall_status"] = "passed"
        
        return results
    
    def print_summary(self, results: Dict[str, any]):
        """Imprimir resumen de resultados"""
        self.print_header("Validation Summary")
        
        print(f"📊 Estado General: {results['overall_status'].upper()}")
        print(f"✅ Checks Pasados: {len(results['passed'])}")
        print(f"⚠️  Warnings: {len(results['warnings'])}")
        print(f"❌ Errores: {len(results['errors'])}")
        
        if results["errors"]:
            print(f"\n❌ Errores que deben ser corregidos:")
            for error in results["errors"]:
                print(f"   • {error}")
        
        if results["warnings"]:
            print(f"\n⚠️  Warnings (recomendado corregir):")
            for warning in results["warnings"]:
                print(f"   • {warning}")
        
        # Recomendaciones
        print(f"\n💡 Próximos pasos:")
        if results["overall_status"] == "passed":
            print("   • ¡Todo está listo! Puedes proceder con el deployment")
            print("   • Ejecuta: python deploy_mainnet.py")
        elif results["overall_status"] == "passed_with_warnings":
            print("   • El deployment puede continuar pero se recomienda revisar warnings")
            print("   • Ejecuta: python deploy_mainnet.py")
        else:
            print("   • Corrige los errores antes de proceder")
            print("   • Vuelve a ejecutar la validación después")
        
        print(f"\n🔗 Enlaces útiles:")
        print("   • GenLayer Docs: https://docs.genlayer.com")
        print("   • ChainAware GitHub: https://github.com/UrbantechPROTON/Chainaware")
        print("   • Deployment Guide: https://docs.chainaware.com/deployment")

def main():
    """Función principal"""
    validator = PreDeploymentValidator()
    results = validator.run_all_checks()
    validator.print_summary(results)
    
    # Exit code basado en resultados
    if results["overall_status"] == "failed":
        sys.exit(1)
    elif results["overall_status"] == "passed":
        sys.exit(0)
    else:  # passed_with_warnings
        sys.exit(0)

if __name__ == "__main__":
    main()